package com.cybage.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.Release;
import com.cybage.model.ReleaseIteration;
import com.cybage.model.ReleaseLog;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.service.ReleaseService;
import com.cybage.utility.Utility;

@RestController
@RequestMapping("/release")
public class ReleaseController {
	
	@Autowired
	private ReleaseService service;
	
	//Default Constructor
	public ReleaseController() {
		System.out.println("Release Controller");
	}
	
	//Getting All Releases available
	@RequestMapping(value="/list/releaseList", method=RequestMethod.GET)
	public ResponseEntity<List<Release>> getAllReleases(HttpSession session){
		System.out.println("getAllReleases");
		
		List<Release> releaseList = service.getAllReleases();
		
		if(releaseList == null || releaseList.isEmpty())
			return new ResponseEntity<List<Release>>(HttpStatus.NOT_FOUND);
		
		//Adding release List to Session
		session.setAttribute("releaseList", releaseList);
		
		return new ResponseEntity<List<Release>>(releaseList, HttpStatus.OK);
		
	}
	
	
	//Getting All Releases available for respective user
	@RequestMapping(value="/list/releaseList/user", method=RequestMethod.GET)
	public ResponseEntity<List<Release>> getAllReleasesForUser(HttpSession session){
		System.out.println("getAllReleasesForUser");
		
		User user = (User)session.getAttribute("user");
		
		//if user has not logged in
		if(user == null )
			return new ResponseEntity<List<Release>>(HttpStatus.BAD_REQUEST);
		
		List<Release> releaseList = service.getAllReleases(user);
		
		if(releaseList == null || releaseList.isEmpty())
			return new ResponseEntity<List<Release>>(HttpStatus.NOT_FOUND);
		
		//Adding release List to Session
		session.setAttribute("releaseList", releaseList);
		
		return new ResponseEntity<List<Release>>(releaseList, HttpStatus.OK);
		
	}
	
	//Getting All ReleaseItearions
	@RequestMapping(value="/list/releaseIteration", method=RequestMethod.GET)
	public ResponseEntity<List<ReleaseIteration>> getAllReleaseWithIteration(HttpSession session){
		System.out.println("getAllReleaseWithIteration");
		
		List<ReleaseIteration> releaseIterationList = service.getAllReleasesWithIterations();
		
		if(releaseIterationList == null || releaseIterationList.isEmpty())
			return new ResponseEntity<List<ReleaseIteration>>(HttpStatus.NOT_FOUND);
		
		//Adding ReleaesIteration List to session
		session.setAttribute("releaseIterationList", releaseIterationList);
		
		return new ResponseEntity<List<ReleaseIteration>>(releaseIterationList, HttpStatus.OK);
	}
	
	//Getting All ReleaseItearions
	@RequestMapping(value="/list/releaseIteration/user", method=RequestMethod.GET)
	public ResponseEntity<List<ReleaseIteration>> getAllReleaseWithIterationForUser(HttpSession session){
		System.out.println("getAllReleaseWithIteration");
		
		//Checking for user in session
		User user = (User)session.getAttribute("user");
		
		if(user == null)
			return new ResponseEntity<List<ReleaseIteration>>(HttpStatus.BAD_REQUEST);
		
		List<ReleaseIteration> releaseIterationList = service.getAllReleasesWithIterations(user);
		
		if(releaseIterationList == null || releaseIterationList.isEmpty())
			return new ResponseEntity<List<ReleaseIteration>>(HttpStatus.NOT_FOUND);
		
		//Adding ReleaesIteration List to session
		session.setAttribute("releaseIterationList", releaseIterationList);
		
		return new ResponseEntity<List<ReleaseIteration>>(releaseIterationList, HttpStatus.OK);
	}

	/*Search Releases by type, status, by title, dates
	@RequestMapping(value="/search/release/byType/{}", method=RequestMethod.GET)
	public searchReleaseByType(@)*/
	
}
