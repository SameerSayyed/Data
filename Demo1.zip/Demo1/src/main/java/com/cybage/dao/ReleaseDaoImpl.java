package com.cybage.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.ItemLog;
import com.cybage.model.Release;
import com.cybage.model.ReleaseItem;
import com.cybage.model.ReleaseIteration;
import com.cybage.model.ReleaseLog;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.model.UserRole;

@Repository
@Transactional
@SuppressWarnings("unchecked")
public class ReleaseDaoImpl implements ReleaseDao {

	@Autowired
	private SessionFactory factory;


	/*List Release*/
	
	//Retrieving all Releases irrespective of user
	@Override
	public List<Release> getAllReleases() {
		List<UserRole> userRoles =  factory.getCurrentSession().createCriteria(UserRole.class).list();
		System.out.println(userRoles);
		return null;
		//return factory.getCurrentSession().createCriteria(Release.class).list();
	}//getAllRelease end
	
	//Retrieving all Releases related to user
	@Override
	public List<Release> getAllReleases(User user) {
		
		return factory.getCurrentSession().createCriteria(Release.class)
				.add(Restrictions.eq("manager", user)).list();
	}
	
	//Retrieving all ReleaseIterations irrespective of user
	@Override
	public List<ReleaseIteration> getAllReleasesWithIterations() {
		
		return factory.getCurrentSession().createCriteria(ReleaseIteration.class).list();
	}//getAllReleaseWithiterations end
	
	//Retrieving all ReleaseIterations related to user
	@Override
	public List<ReleaseIteration> getAllReleasesWithIterations(User user) {
		
		return factory.getCurrentSession().createCriteria(ReleaseIteration.class)
				.add(Restrictions.eq("release.manager", user)).list();
	}
	
	//Retrieving all ReleaseItems irrespective of user
	@Override
	public List<ReleaseItem> getAllReleseWithItems() {
		
		return factory.getCurrentSession().createCriteria(ReleaseItem.class).list();
	}//getAllReleaseWithItems end
	
	//Retrieving all ReleaseItems related to user
	@Override
	public List<ReleaseItem> getAllReleseWithItems(User user) {
		
		return factory.getCurrentSession().createCriteria(ReleaseItem.class)
				.add(Restrictions.eq("release.manager", user)).list();
	}
	
	
	/*Search Releases by type, status, by title, dates*/
	
	//Searching for Releases by Type
	@Override
	public List<Release> searchReleaseByType(ReleaseType releaseType) {
		
		return factory.getCurrentSession().createCriteria(Release.class)
				.add(Restrictions.eq("releaseType", releaseType)).list();
	}//searchReleaseByType end
	
	//Searching for ReleasesByStatus
	@Override
	public List<Release> searchReleaseByStatus(ReleaseStatus releaseStatus) {
		
		return factory.getCurrentSession().createCriteria(Release.class)
				.add(Restrictions.eq("releaseStatus", releaseStatus)).list();
	}//searchReleaseByStatus end
	
	//Searching for Releases by title
	@Override
	public List<Release> searchReleaseByTitle(String title) {
		
		return factory.getCurrentSession().createCriteria(Release.class)
				.add(Restrictions.like("title", "%" + title + "%")).list();
	}//searchReleaseByTitle end
	
	//searching for Releases By Start Dates
	@Override
	public List<Release> searchReleaseByStartDate(Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}
	
	//searching for Releases by Planned Dates
	@Override
	public List<Release> serachReleaseByPlannedDate(Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}
	
	//searching for Releases by Released Dates
	@Override
	public List<Release> searchReleaseByReleasedDate(Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ReleaseIteration> searchReleaseIterations(Release release) {
		
		return factory.getCurrentSession().createCriteria(ReleaseIteration.class)
				.add(Restrictions.eq("release", release)).list();
	}//searchReleaseIterations end

	@Override
	public List<ReleaseItem> searchReleaseItems(Release release) {
		
		return factory.getCurrentSession().createCriteria(ReleaseItem.class)
				.add(Restrictions.eq("release", release)).list();
	}//searchReleaseitems end
	
	
	
	/*Manage Release*/
	
	//Adding Release
	@Override
	public Release addRelease(Release release, ReleaseLog releaseLog) {
		Session session = factory.getCurrentSession();
				
		//Adding Release to Release Table
		session.save(release);
		
		//Adding Log to ReleaseLog Table
		//session.save(releaseLog);
		
		return release;
	}//addRelease end
	
	//Adding Item to existing Release
	@Override
	public Release addItemToRelease(ReleaseItem releaseItem, ItemLog itemLog) {
		Session session = factory.getCurrentSession();
		
		//Adding Item to Items table
		session.save(releaseItem.getItem());
		
		//Adding ReleaseItem to ReleaseItem Link Table
		session.save(releaseItem);
		
		//Adding Log to ItemsLog Table
		session.save(itemLog);
		
		return releaseItem.getRelease();
	}//addItemToRelease end
	
	//Adding new Release with Iteration
	@Override
	public Release addReleaseWithIteration(ReleaseIteration releaseIteration, ReleaseLog releaseLog) {
		Session session = factory.getCurrentSession();
		
		//Adding Release to ReleaseTable
		session.save(releaseIteration.getRelease());
		
		//Adding Iteration to IterationTable
		session.save(releaseIteration.getIteration());
		
		//Adding Release and Iteration to ReleaseIteration Link Table
		session.save(releaseIteration);
		
		//Adding Log to ReleaseLog Table
		session.save(releaseLog);
		
		return releaseIteration.getRelease();
	}//addReleaseWithIteration end

	//Updating Release
	@Override
	public Release updateRelease(Release release, ReleaseLog releaseLog) {
		Session session = factory.getCurrentSession();
		
		//Updating Release in Release Table
		session.update(release);
		
		//Adding Log to releaseLog Table
		session.save(releaseLog);
		
		return null;
	}//updateRelease end

	//Deleting Release
	@Override
	public Release deleteRelease(Release release) {
		Session session = factory.getCurrentSession();
		
		//Deleting Release from ReleaseIteration Table
		session.createQuery("DELETE FROM ReleaseIteration WHERE release=:rel").setParameter("rel", release).executeUpdate();
		
		//Deleting Release from ReleaseLog Table
		session.createQuery("DELETE FROM ReleaseLog WHERE release=:rel").setParameter("rel", release).executeUpdate();
		
		//Deleting Release from ReleaseItems Table
		session.createQuery("DELETE FROM ReleaseItem WHERE release=:rel").setParameter("rel", release).executeUpdate();
		
		//Deleting Release from Release Table
		session.delete(release);
		
		return release;
	}//deleteRelease end

}
