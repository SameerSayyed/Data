package com.cybage.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.ItemLog;
import com.cybage.model.Iteration;
import com.cybage.model.IterationItem;
import com.cybage.model.IterationLog;
import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseIteration;
import com.cybage.model.User;

@SuppressWarnings("unchecked")
@Transactional
@Repository
public class IterationDaoImpl implements IterationDao {
	
	@Autowired
	private SessionFactory factory;
	
	/*List Iteration*/
	//Retrieving all Iterations
	@Override
	public List<Iteration> getAllIterations() {
		
		return factory.getCurrentSession().createCriteria(Iteration.class).list();
	}
	
	//Retrieving all IterationItems
	@Override
	public List<IterationItem> getAllIterationsWithItems() {
		
		return factory.getCurrentSession().createCriteria(IterationItem.class).list();
	}
	
	
	
	/*Search iterations by status, type, dates*/
	@Override
	public List<Iteration> searchIterationByStutus(IterationStatus iterationStatus) {
		
		return factory.getCurrentSession().createCriteria(Iteration.class)
				.add(Restrictions.eq("iterationStatus", iterationStatus)).list();
	}

	@Override
	public List<Iteration> searchIterationByType(IterationType iterationType) {
		
		return factory.getCurrentSession().createCriteria(Iteration.class)
				.add(Restrictions.eq("iterationType", iterationType)).list();
	}

	@Override
	public List<Iteration> searchIterationByDates(Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<Iteration> searchIterationByTitle(String title) {
		
		return factory.getCurrentSession().createCriteria(Iteration.class)
				.add(Restrictions.like("title", "%" + title + "%")).list();
	}
	
	
	@Override
	public List<IterationItem> searchIterationItems(Iteration iteration) {
		
		return factory.getCurrentSession().createCriteria(IterationItem.class)
				.add(Restrictions.eq("iteration", iteration)).list();
	}
	
	
	/*Manage Iteration*/
	
	//Add new Iteration record into iteration table Using Methods
	@Override
	public Iteration addIteration(ReleaseIteration releaseIteration, IterationLog iterationLog) {
		Session session = factory.getCurrentSession();
		
		//Adding Iteration in Iteration table
		session.save(releaseIteration.getIteration());
			
		//Adding Iteration in Release-Iteration link table
		session.save(releaseIteration);
		
		//Adding Log to IterationLog table
		session.save(iterationLog);
		
		
		return releaseIteration.getIteration();
		
	}

	//Update existing Iteration Details Using Methods
	@Override
	public Iteration updateIteration(Iteration iteration, IterationLog iterationLog) {
		Session session = factory.getCurrentSession();
		
		//Updating iteration Table
		session.update(iteration);
		
		//Adding Log to IterationLog Table
		session.save(iterationLog);
		
		return iteration;
	}
	
	//Delete Iteration Record From Db by id Using HQL
	@Override
	public Iteration deleteIterationById(String id) {
		Session session = factory.getCurrentSession();
		
		//Checking for availability of iteration with given id
		Iteration iteration = (Iteration) session.createQuery("SELECT i FROM Iteration i WHERE id=:it")
				.setParameter("it", id).uniqueResult();
		
		if(iteration != null){
			
			//Deleting iteration from Release-Iteration link table
			session.createQuery("DELETE FROM ReleaseIteration WHERE iteration=:iterate")
				.setParameter("iterate", iteration).executeUpdate();
			
			//Deleting iteration from IterationLog Table
			session.createQuery("DELETE FROM IterationLog WHERE iteration=:iterate")
				.setParameter("iterate", iteration).executeUpdate();
			
			//Deleting Iteration from IterationItem Link Table
			session.createQuery("DELETE FROM IterationItem WHERE iteration=:iterate")
				.setParameter("iterate", iteration).executeUpdate();
			
			//Deleting iteration from iteration table
			factory.getCurrentSession().delete(iteration);
			
			return iteration;
		}
		return null;
	}

	//Delete Iteration from db by iteration pojo
	@Override
	public Iteration deleteItertion(Iteration iteration) {
		Session session = factory.getCurrentSession();
		
		//Deleting iteration from Release-Iteration link table
		session.createQuery("DELETE FROM ReleaseIteration WHERE iteration=:iterat")
			.setParameter("iterat", iteration).executeUpdate();
		
		//Deleting logs related to this iteration from IterationLog table
		session.createQuery("DELETE FROM IterationLog WHERE iteration=:iterate")
			.setParameter("iterate", iteration).executeUpdate();
		
		//Deleting Iteration from IterationItem Link Table
		session.createQuery("DELETE FROM IterationItem WHERE iteration=:iterate")
			.setParameter("iterate", iteration).executeUpdate();
		
		//Deleting iteration from iteration table
		factory.getCurrentSession().delete(iteration);
		
		return iteration;
	}

	
	//Adding new Item to existing Iteration
	@Override
	public IterationItem addItemToIteration(IterationItem iterationItem, ItemLog itemLog) {
		Session session = factory.getCurrentSession();
		
		//Adding new Item to Items Table
		session.save(iterationItem.getItem());
		
		//Adding Item and Iteration to IterationItem Table
		session.save(iterationItem);
		
		//Adding log to ItemsLog Table
		session.save(itemLog);
		
		return iterationItem;
	}

}
