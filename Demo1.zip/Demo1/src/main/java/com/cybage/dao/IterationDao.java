package com.cybage.dao;

import java.util.Date;
import java.util.List;

import com.cybage.model.ItemLog;
import com.cybage.model.Iteration;
import com.cybage.model.IterationItem;
import com.cybage.model.IterationLog;
import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseIteration;
import com.cybage.model.User;

public interface IterationDao {
	/*List Iteration*/
	List<Iteration> getAllIterations();
	List<IterationItem> getAllIterationsWithItems();
	
	
	/*Search iterations by status, type, dates*/
	List<Iteration> searchIterationByStutus(IterationStatus iterationStatus);
	List<Iteration> searchIterationByType(IterationType iterationType);
	List<Iteration> searchIterationByDates(Date startDate, Date endDate);
	List<Iteration> searchIterationByTitle(String title);
	
	List<IterationItem> searchIterationItems(Iteration iteration);
	
	/*Manage Iteration*/
	Iteration addIteration(ReleaseIteration releaseIteration, IterationLog iterationLog);
	Iteration updateIteration(Iteration iteration, IterationLog iterationLog);
	Iteration deleteIterationById(String id);
	Iteration deleteItertion(Iteration iteration);
	
	IterationItem addItemToIteration(IterationItem iterationItem, ItemLog itemLog);
}
