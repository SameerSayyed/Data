
var items = [];
var iterations = [];

app.service('dataService', ['$http', function ($http) 
{
	var homeUrl = 'http://localhost:8080/Restful/home';
	var releaseUrl = 'http://localhost:8080/Restful/release';
	var iterationUrl = 'http://localhost:8080/Restful/iteration';
	
	this.getRelease = function () 
    {
        return $http.get(releaseUrl + "/list/releaseList");
    };	
	
	this.getReleaseType = function()
    {
    	return $http.get(homeUrl + "/list/releasetype");
    };
	
    this.getReleaseTo = function()
    {
    	return $http.get(homeUrl + "/list/releaseto");
    };
    
	this.getReleaseStatus = function()
    {
    	return $http.get(homeUrl + "/list/releasestatus");
    };
    
    this.addNewRelease = function(newRelease)
    {
    	return $http.post(releaseUrl + "/add/release", newRelease);
    };
    
    this.getIterationType = function()
    {
    	return $http.get(homeUrl + "/list/iterationType");
    };

	this.getIterationStatus = function()
    {
    	return $http.get(homeUrl + "/list/iterationStatus");
    };
    
    this.addReleaseIteration = function(releaseIteration)
    {
    	return $http.post(iterationUrl + "/newReleaseIteration", releaseIteration);
    }
                                
}]);

app.controller("AddReleaseController",function($scope, dataService)
{	
	dataService.getReleaseType()
    .then(function (response) 
    {
        $scope.releaseType = response.data;
    }, function (error)
    {
        $scope.status1 = 'Unable to load release types: ' + error.message;
    });
	
	dataService.getReleaseTo()
    .then(function (response) 
    {
        $scope.releaseTo = response.data;
    }, function (error)
    {
        $scope.status2 = 'Unable to load release to: ' + error.message;
    });
	
	dataService.getReleaseStatus()
    .then(function (response) 
    {
    	var r = response.data;
        $scope.releaseStatus = response.data;
    }, function (error)
    {
        $scope.status3 = 'Unable to load release status: ' + error.message;
    });
	
	$scope.addItem = function()
	{
		items.push($scope.item);
		$scope.item = "";
		/*for(var i=0;i<items.length;i++)
		{
			window.alert(items[i].name);
		}*/
	};
	
	$scope.addRelease = function()
	{
		console.log("releaseT : " + angular.fromJson($scope.release.releaseType));
		var releaseItems = [];
		for(var i in items){
			releaseItem = {release: $scope.release, item: items[i]};
			releaseItems.push(releaseItem);
		}
		for(var i in releaseItems){
			console.log(releaseItems[i]);
		}
		
		dataService.addNewRelease(releaseItems)
        .then(function (response)
        {
            window.alert("response send..");
        }, function(error) {
            $scope.status4 = 'Unable to insert release: ' + error.message;
        });
	}
})


app.controller("ViewReleaseController",function($scope, dataService)
{
	dataService.getRelease()
    .then(function (response) 
    {
        $scope.releases = response.data;
    }, function (error)
    {
        $scope.status5 = 'Unable to load customer data: ' + error.message;
    });
})

app.controller("AddReleaseIterationController",function($scope, dataService)
{
	dataService.getReleaseType()
    .then(function (response) 
    {
        $scope.releaseType = response.data;
    }, function (error)
    {
        $scope.status6 = 'Unable to load release types: ' + error.message;
    });
	
	dataService.getReleaseTo()
    .then(function (response) 
    {
        $scope.releaseTo = response.data;
    }, function (error)
    {
        $scope.status7 = 'Unable to load release to: ' + error.message;
    });
	
	dataService.getReleaseStatus()
    .then(function (response) 
    {
    	var r = response.data;
        $scope.releaseStatus = response.data;
    }, function (error)
    {
        $scope.status8 = 'Unable to load release status: ' + error.message;
    });
	
	dataService.getIterationType()
    .then(function (response) 
    {
        $scope.iterationType = response.data;
        console.log($scope.releasetypes);
    }, function (error)
    {
        $scope.status10 = 'Unable to load iteration types: ' + error.message;
    });
	
	dataService.getIterationStatus()
    .then(function (response) 
    {
    	var r = response.data;
        $scope.iterationStatus = response.data;
    }, function (error)
    {
        $scope.status11 = 'Unable to load iteration status: ' + error.message;
    });
	
	$scope.addIteration = function()
	{
		dataService.addReleaseIteration($scope.release)
        .then(function (response)
        {
            console.log("response send..");
        }, function(error) {
            $scope.status12 = 'Unable to insert release: ' + error.message;
        });
	}
	
	$scope.addIteration = function()
	{
		iterations.push($scope.iteration);
		$scope.iteration = "";
	}
	
	
	$scope.addReleaseIteration = function()
	{
		console.log("hiiii");
		var releaseIterations = [];
		for(var i in iterations){
			releaseIteration = {release: $scope.release, iteration: iterations[i]};
			releaseIterations.push(releaseIteration);
		}
		for(var i in releaseIterations){
			console.log(releaseIterations[i]);
		}
		
		dataService.addReleaseIteration($scope.release)
        .then(function (response)
        {
            window.alert("response send..");
        }, function(error) {
            $scope.status4 = 'Unable to insert release: ' + error.message;
        });
	}
})