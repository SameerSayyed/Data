var app = angular.module("mainApp", ['ngRoute']);
app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
    when('/addRelease', {
      templateUrl: 'addrelease.jsp',
      controller: 'AddReleaseController'
    }).
    when('/viewRelease', {
      templateUrl: 'viewrelease.jsp',
      controller: 'ViewReleaseController'
    }).
    when('/addReleaseIteration', {
        templateUrl: 'addReleaseIteration.jsp',
        controller: 'AddReleaseIterationController'
      }).
    otherwise({
      redirectTo: '/viewRelease'
    });
  }
]);

