package com.cybage.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.service.HomeService;

@RestController
@RequestMapping("/home")
public class HomeController {
	
	@Autowired
	private HomeService service;
	
	//default constructor
	public HomeController() {
		System.out.println("Home Controller Ctor");
	}
	
	/*Validating User*/
	@RequestMapping(value="/login/user", method = RequestMethod.POST)
	public ResponseEntity<User> validateUser(@RequestBody User user, HttpSession session) 
	{
		//Validate user
		user = service.validateUser(user);
		
		//if user is null then credentials are invalid
		if(user == null)
		    return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		
		//Adding valid user to session
        session.setAttribute("user", user);
        
        return new ResponseEntity<User>(user, HttpStatus.OK);
    }
	
	/*Logout user*/
	@RequestMapping(value="/logout/user", method = RequestMethod.GET)
	public ResponseEntity<User> logoutUser(HttpSession session) 
	{
		//Checking for existence of the user
		User user = (User)session.getAttribute("user");
		
		if(user == null)
		    return new ResponseEntity<User>(HttpStatus.BAD_REQUEST);
		
		session.invalidate();
		
        return new ResponseEntity<User>(user, HttpStatus.OK);
    }
	
	/*Getters for all Release reference Data*/

	@RequestMapping(value = "/list/releasetype", method = RequestMethod.GET)
	public ResponseEntity<List<ReleaseType>> getAllReleaseTypes(HttpSession session){
		
		System.out.println("getAllReleaseTypes");
		
		//Retrieving ReleaseType list from db
        List<ReleaseType> releaseTypeList = service.getAllReleaseTypes();
       
        if(releaseTypeList == null || releaseTypeList.isEmpty()){
            return new ResponseEntity<List<ReleaseType>>(HttpStatus.NOT_FOUND);//You many decide to return HttpStatus.NOT_FOUND
        }
        
        //Adding releaseTypeList in session
        session.setAttribute("releaseTypeList", releaseTypeList);
        
        return new ResponseEntity<List<ReleaseType>>(releaseTypeList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/list/releasestatus", method = RequestMethod.GET)
	public ResponseEntity<List<ReleaseStatus>> getAllReleaseStatuses(HttpSession session){
		System.out.println("getAllReleaseStatus");
        
		//Retrieving ReleaseStatus list from db
		List<ReleaseStatus> releaseStatusList = service.getAllReleaseStatuses();
        
        if(releaseStatusList == null || releaseStatusList.isEmpty())
        {
            return new ResponseEntity<List<ReleaseStatus>>(HttpStatus.NOT_FOUND);
        }
        
        //Adding releaseStatus List in session
        session.setAttribute("releaseStatusList", releaseStatusList);
        
        return new ResponseEntity<List<ReleaseStatus>>(releaseStatusList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/list/releaseto", method = RequestMethod.GET)
	public ResponseEntity<List<ReleaseTo>> getAllReleaseTos(HttpSession session){
		System.out.println("getAllReleaseTo");
        
		//Retrieving ReleaseTo list from db
		List<ReleaseTo> releaseToList = service.getAllReleaseTos();
        
        if(releaseToList == null || releaseToList.isEmpty()){
            return new ResponseEntity<List<ReleaseTo>>(HttpStatus.NO_CONTENT);
        }
        
        //Adding releaseTo List in session
        session.setAttribute("releaseToList", releaseToList);
        
        return new ResponseEntity<List<ReleaseTo>>(releaseToList, HttpStatus.OK);
	}
	
	
	/*Getters for all Iteration reference Data*/
	
	@RequestMapping(value = "/list/iterationStatus", method = RequestMethod.GET)
	public ResponseEntity<List<IterationStatus>> getAllIterationStatuses(HttpSession session){
		System.out.println("getAllIterationStatus");
		
		//Retrieving IterationStatus list from db
		List<IterationStatus> iterationStatusList = service.getAllIterationStatuses();
		
		if(iterationStatusList == null || iterationStatusList.isEmpty())
			return new ResponseEntity<List<IterationStatus>>(HttpStatus.NOT_FOUND);
		
		//Adding IterationStatus List to Session
		session.setAttribute("iterationStatusList", iterationStatusList);
		
		return new ResponseEntity<List<IterationStatus>>(iterationStatusList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/list/iterationType", method = RequestMethod.GET)
	public ResponseEntity<List<IterationType>> getAllItearationTypes(HttpSession session){
		System.out.println("getAllIterationType");
		
		//Retrieving IterationType list from db
		List<IterationType> iterationTypeList = service.getAllItearationTypes();
		
		if(iterationTypeList == null || iterationTypeList.isEmpty())
			return new ResponseEntity<List<IterationType>>(HttpStatus.NOT_FOUND);
		
		//Adding IterationType List to Session
		session.setAttribute("iterationTypeList", iterationTypeList);
		
		return new ResponseEntity<List<IterationType>>(iterationTypeList, HttpStatus.OK);
		
	}
}
