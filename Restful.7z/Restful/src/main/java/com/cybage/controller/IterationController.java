package com.cybage.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.ItemLog;
import com.cybage.model.Iteration;
import com.cybage.model.IterationItem;
import com.cybage.model.IterationLog;
import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseIteration;
import com.cybage.model.User;
import com.cybage.service.IterationService;
import com.cybage.utility.Utility;

@RestController
@RequestMapping("/iteration")
public class IterationController {
	
	@Autowired
	private IterationService service;
	
	public IterationController() {
		System.out.println("In IterationController");
	}
	
	
	/*List Iteration*/
	@RequestMapping(value="/list", method=RequestMethod.GET)
	public ResponseEntity<List<Iteration>> getAllIterations(HttpSession session){
		
		List<Iteration> iterationList = service.getAllIterations();
		
		if(iterationList == null || iterationList.isEmpty())
			return new ResponseEntity<List<Iteration>>(HttpStatus.NOT_FOUND);
		
		session.setAttribute("iterationList", iterationList);
		
		return new ResponseEntity<List<Iteration>>(iterationList, HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/list/items", method=RequestMethod.GET)
	public ResponseEntity<List<IterationItem>> getAllIterationsWithItems(HttpSession session){
		
		List<IterationItem> iterationItemList = service.getAllIterationsWithItems();
		
		if(iterationItemList == null || iterationItemList.isEmpty())
			return new ResponseEntity<List<IterationItem>>(HttpStatus.NOT_FOUND);
		
		session.setAttribute("iterationItemList", iterationItemList);
		
		return new ResponseEntity<List<IterationItem>>(iterationItemList, HttpStatus.OK);
		
	}
	
	
	/*Search iterations by status, type, dates*/
	//Search Iteration by Status
	@RequestMapping(value="/search/byStatus/{statusId}", method=RequestMethod.GET)
	public ResponseEntity<List<Iteration>> searchIterationByStatus(@PathVariable String statusId, HttpSession session){
		
		IterationStatus iterationStatus = null;
		
		List<IterationStatus> itertionStatusList = (List<IterationStatus>)session.getAttribute("iterationStatusList");
		
		if(itertionStatusList == null)
			return new ResponseEntity<List<Iteration>>(HttpStatus.BAD_REQUEST);
		
		for (IterationStatus iterationStatus2 : itertionStatusList) {
			if(iterationStatus2.getId().equals(statusId))
				iterationStatus = iterationStatus2;
		}
		
		List<Iteration> iterationList = service.searchIterationByStatus(iterationStatus);
		
		if(iterationList == null || iterationList.isEmpty())
			return new ResponseEntity<List<Iteration>>(HttpStatus.NOT_FOUND);
		
		session.setAttribute("iterationList", iterationList);
		
		return new ResponseEntity<List<Iteration>>(iterationList, HttpStatus.OK);
	}
	
	//Search Iteration by Type
	@RequestMapping(value="/search/byType/{typeId}", method=RequestMethod.GET)
	public ResponseEntity<List<Iteration>> searchIterationByType(@PathVariable String typeId, HttpSession session){
		
		IterationType iterationType = null;
		
		List<IterationType> iterationTypeList = (List<IterationType>)session.getAttribute("iterationTypeList");
		
		if(iterationTypeList == null)
			return new ResponseEntity<List<Iteration>>(HttpStatus.BAD_REQUEST);
		
		for (IterationType iterationType2 : iterationTypeList) {
			if(iterationType2.getId().equals(typeId))
				iterationType = iterationType2;
		}
		
		List<Iteration> iterationList = service.searchIterationByType(iterationType);
		
		if(iterationList == null || iterationList.isEmpty())
			return new ResponseEntity<List<Iteration>>(HttpStatus.NOT_FOUND);
		
		session.setAttribute("iterationList", iterationList);
		
		return new ResponseEntity<List<Iteration>>(iterationList, HttpStatus.OK);
	}
	
	//Search Iteration by Dates
	@RequestMapping(value="/search/byDates", method=RequestMethod.POST)
	public ResponseEntity<List<Iteration>> searchIterationByDates(@RequestBody Date startDate, HttpSession session){
		
		List<Iteration> iterationList = service.searchIterationByDates(startDate, new Date());
		
		if(iterationList == null || iterationList.isEmpty())
			return new ResponseEntity<List<Iteration>>(HttpStatus.NOT_FOUND);
		
		session.setAttribute("iterationList", iterationList);
		
		return new ResponseEntity<List<Iteration>>(iterationList, HttpStatus.OK);
	}
	
	//Search Iteration by title
	@RequestMapping(value="/search/byTitle/{title}", method=RequestMethod.GET)
	public ResponseEntity<List<Iteration>> searchIterationByTitle(@PathVariable String title, HttpSession session){
		
		List<Iteration> iterationList = service.searchIterationByTitle(title);
		
		if(iterationList == null || iterationList.isEmpty())
			return new ResponseEntity<List<Iteration>>(HttpStatus.NOT_FOUND);
		
		session.setAttribute("iterationList", iterationList);
		
		return new ResponseEntity<List<Iteration>>(iterationList, HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/search/items/{itertionId}", method=RequestMethod.POST)
	public ResponseEntity<List<IterationItem>> searchIterationItems(@PathVariable String iterationId, HttpSession session){
		
		Iteration iteration = null;
		List<Iteration> iterationList = (List<Iteration>)session.getAttribute("iterationList");
		
		if(iterationList == null)
			return new ResponseEntity<List<IterationItem>>(HttpStatus.BAD_REQUEST);
		
		for (Iteration iteration2 : iterationList) {
			if(iteration2.getId().equals(iterationId))
				iteration = iteration2;
		}
		
		List<IterationItem> iterationItemList =  service.searchIterationItems(iteration);
		
		if(iterationItemList == null || iterationItemList.isEmpty())
			return new ResponseEntity<List<IterationItem>>(HttpStatus.NOT_FOUND);
		
		session.setAttribute("iterationItemList", iterationItemList);
	
		return new ResponseEntity<List<IterationItem>>(iterationItemList, HttpStatus.OK);
	}
	
	//Adding new Iteration
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public ResponseEntity<Iteration> addNewIteration(@RequestBody ReleaseIteration releaseIteration,HttpSession session){
		
		User user = (User)session.getAttribute("user");
		
		if(user == null || releaseIteration == null)
			return new ResponseEntity<Iteration>(HttpStatus.BAD_REQUEST);
		
		//Adding createdBy and createdDate fields to iteration
		releaseIteration.getIteration().setCreatedBy(user.getFirstName().concat(user.getLastName()));
		releaseIteration.getIteration().setCreatedDate(new Date());
		
		Iteration newIteration = service.addIteration(releaseIteration,
				new IterationLog(Utility.getUUID(), releaseIteration.getIteration(), new Date(), user.getFirstName().concat(user.getLastName())));
		
		return new ResponseEntity<Iteration>(newIteration, HttpStatus.OK);
		
	}
	
	//Adding new Item to Iteration
	@RequestMapping(value="/add/item", method=RequestMethod.POST)
	public ResponseEntity<IterationItem> addItemToIteration(@RequestBody IterationItem iterationItem,HttpSession session){
		
		User user = (User)session.getAttribute("user");
		
		if(user == null || iterationItem == null)
			return new ResponseEntity<IterationItem>(HttpStatus.BAD_REQUEST);
		
		//Adding createdBy and createdDate fields to Item
		iterationItem.getItem().setCreatedBy(user.getFirstName().concat(user.getLastName()));
		iterationItem.getItem().setCreatedDate(new Date());
		
		
		IterationItem newIterationItem = service.addItemToIteration(iterationItem,
				new ItemLog(Utility.getUUID(), iterationItem.getItem(), new Date(), user.getFirstName().concat(user.getLastName())));
		
		
		return new ResponseEntity<IterationItem>(newIterationItem, HttpStatus.OK);
		
	}
	
	//Update Iteraton
	@RequestMapping(value="/update", method=RequestMethod.POST)
	public ResponseEntity<Iteration> updateIteration(@RequestBody Iteration iteration,HttpSession session){
		
		User user = (User)session.getAttribute("user");
		
		if(user == null || iteration == null)
			return new ResponseEntity<Iteration>(HttpStatus.BAD_REQUEST);
		
		
		Iteration updatedIteration = service.updateIteration(iteration, 
				new IterationLog(Utility.getUUID(), iteration, new Date(), user.getFirstName().concat(user.getLastName())));
		
		return new ResponseEntity<Iteration>(updatedIteration, HttpStatus.OK);
		
	}
	
	
	//DeleteIteration
	@RequestMapping(value="/delete/{id}")
	public ResponseEntity<Iteration> deleteIteration(@PathVariable String iterationId, HttpSession session){
		
		Iteration iteration = null;
		List<Iteration> iterationList = (List<Iteration>)session.getAttribute("iterationList");
		
		if(iterationList == null)
			return new ResponseEntity<Iteration>(HttpStatus.BAD_REQUEST);
		
		for (Iteration iteration2 : iterationList) {
			if(iteration2.getId().equals(iterationId))
				iteration = iteration2;
		}
		
		Iteration deletedIteration = service.deleteItertion(iteration);
		return new ResponseEntity<Iteration>(deletedIteration, HttpStatus.OK);
	}
}
