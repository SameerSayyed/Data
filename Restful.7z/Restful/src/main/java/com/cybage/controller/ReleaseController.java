package com.cybage.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.ItemLog;
import com.cybage.model.Release;
import com.cybage.model.ReleaseItem;
import com.cybage.model.ReleaseIteration;
import com.cybage.model.ReleaseLog;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.service.ReleaseService;
import com.cybage.utility.Utility;

@RestController
@RequestMapping("/release")
public class ReleaseController {
	
	@Autowired
	private ReleaseService service;
	
	//Default Constructor
	public ReleaseController() {
		System.out.println("Release Controller");
	}
	
	//Getting All Releases available
	@RequestMapping(value="/list/releaseList", method=RequestMethod.GET)
	public ResponseEntity<List<Release>> getAllReleases(HttpSession session){
		System.out.println("getAllReleases");
		
		List<Release> releaseList = service.getAllReleases();
		
		if(releaseList == null || releaseList.isEmpty())
			return new ResponseEntity<List<Release>>(HttpStatus.NOT_FOUND);
		
		//Adding release List to Session
		session.setAttribute("releaseList", releaseList);
		
		return new ResponseEntity<List<Release>>(releaseList, HttpStatus.OK);
		
	}
	
	
	//Getting All Releases available for respective user
	@RequestMapping(value="/list/releaseList/user", method=RequestMethod.GET)
	public ResponseEntity<List<Release>> getAllReleasesForUser(HttpSession session){
		System.out.println("getAllReleasesForUser");
		
		User user = (User)session.getAttribute("user");
		
		//if user has not logged in
		if(user == null )
			return new ResponseEntity<List<Release>>(HttpStatus.BAD_REQUEST);
		
		List<Release> releaseList = service.getAllReleases(user);
		
		if(releaseList == null || releaseList.isEmpty())
			return new ResponseEntity<List<Release>>(HttpStatus.NOT_FOUND);
		
		//Adding release List to Session
		session.setAttribute("releaseList", releaseList);
		
		return new ResponseEntity<List<Release>>(releaseList, HttpStatus.OK);
		
	}
	
	//Getting All ReleaseItearions
	@RequestMapping(value="/list/releaseIteration", method=RequestMethod.GET)
	public ResponseEntity<List<ReleaseIteration>> getAllReleaseWithIteration(HttpSession session){
		System.out.println("getAllReleaseWithIteration");
		
		List<ReleaseIteration> releaseIterationList = service.getAllReleasesWithIterations();
		
		if(releaseIterationList == null || releaseIterationList.isEmpty())
			return new ResponseEntity<List<ReleaseIteration>>(HttpStatus.NOT_FOUND);
		
		//Adding ReleaesIteration List to session
		session.setAttribute("releaseIterationList", releaseIterationList);
		
		return new ResponseEntity<List<ReleaseIteration>>(releaseIterationList, HttpStatus.OK);
	}
	
	//Getting All ReleaseItearions
	@RequestMapping(value="/list/releaseIteration/user", method=RequestMethod.GET)
	public ResponseEntity<List<ReleaseIteration>> getAllReleaseWithIterationForUser(HttpSession session){
		System.out.println("getAllReleaseWithIteration");
		
		//Checking for user in session
		User user = (User)session.getAttribute("user");
		
		if(user == null)
			return new ResponseEntity<List<ReleaseIteration>>(HttpStatus.BAD_REQUEST);
		
		List<ReleaseIteration> releaseIterationList = service.getAllReleasesWithIterations(user);
		
		if(releaseIterationList == null || releaseIterationList.isEmpty())
			return new ResponseEntity<List<ReleaseIteration>>(HttpStatus.NOT_FOUND);
		
		//Adding ReleaesIteration List to session
		session.setAttribute("releaseIterationList", releaseIterationList);
		
		return new ResponseEntity<List<ReleaseIteration>>(releaseIterationList, HttpStatus.OK);
	}

	
	/*Search Releases by type, status, by title, dates*/
	//Searching Release by Type
	@RequestMapping(value="/search/byType/{id}", method=RequestMethod.GET)
	public ResponseEntity<List<Release>> searchReleaseByType(@PathVariable String typeId, HttpSession session){
		
		ReleaseType releaseType = null;
		
		List<ReleaseType> releaseTypeList = (List<ReleaseType>)session.getAttribute("releaseTypeList");
		
		if(releaseTypeList != null){
			//search for the required Release Type
			for (ReleaseType releaseType2 : releaseTypeList) {
				if(releaseType2.getId().equals(typeId))
					releaseType = releaseType2;
			}
			
			List<Release> releaseList = service.searchReleaseByType(releaseType);
			if(releaseList == null || releaseList.isEmpty())
				return new ResponseEntity<List<Release>>(HttpStatus.NOT_FOUND);
			
			session.setAttribute("releaseList", releaseList);
			
			return new ResponseEntity<List<Release>>(releaseList, HttpStatus.OK);
			
		}
		
		return new ResponseEntity<List<Release>>(HttpStatus.BAD_REQUEST);
	}

	//Searching Release by Status
	@RequestMapping(value="/search/byStatus/{id}", method=RequestMethod.GET)
	public ResponseEntity<List<Release>> searchReleaseByStatus(@PathVariable String statusId, HttpSession session){
		
		ReleaseStatus releaseStatus = null;
		
		List<ReleaseStatus> releaseStatusList = (List<ReleaseStatus>)session.getAttribute("releaseStatusList");
		
		if(releaseStatusList != null){
			//search for the required Release Type
			for (ReleaseStatus releaseStatus2 : releaseStatusList) {
				if(releaseStatus2.getId().equals(statusId))
					releaseStatus = releaseStatus2;
			}
			
			List<Release> releaseList = service.searchReleaseByStatus(releaseStatus);
			if(releaseList == null || releaseList.isEmpty())
				return new ResponseEntity<List<Release>>(HttpStatus.NOT_FOUND);
			
			session.setAttribute("releaseList", releaseList);
			
			return new ResponseEntity<List<Release>>(releaseList, HttpStatus.OK);
			
		}
		
		return new ResponseEntity<List<Release>>(HttpStatus.BAD_REQUEST);
	}
	
	//Searching Release by Title
	@RequestMapping(value="/search/byTitle/{title}", method=RequestMethod.GET)
	public ResponseEntity<List<Release>> searchReleaseByTitle(@PathVariable String title, HttpSession session){
		
		List<Release> releaseList = service.searchReleaseByTitle(title);
		if(releaseList == null || releaseList.isEmpty())
			return new ResponseEntity<List<Release>>(HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Release>>(releaseList, HttpStatus.OK);
		
	}
	
	//searching release by dates
	@RequestMapping(value = "/search/byDate", method=RequestMethod.POST)
	public ResponseEntity<List<Release>> searchReleaseByDate(@RequestBody Date startDate, HttpSession session){
		
		List<Release> releaseList = service.searchReleaseByDate(startDate, new Date());
		
		if(releaseList == null || releaseList.isEmpty())
			return new ResponseEntity<List<Release>>(HttpStatus.NOT_FOUND);
		
		session.setAttribute("releaseList", releaseList);
		
		return new ResponseEntity<List<Release>>(releaseList, HttpStatus.OK);
		
	}
	
	//Search ReleaseIteration
	@RequestMapping(value="/search/iterations/{releaseId}", method=RequestMethod.GET)
	public ResponseEntity<List<ReleaseIteration>> searchReleaseIteration(@PathVariable String releaseId, HttpSession session){
		
		Release release = null;
		
		List<Release> releaseList = (List<Release>)session.getAttribute("releaseList");
		if(releaseList != null){
			
			for (Release release2 : releaseList) {
				if(release2.getId().equals(releaseId))
					release = release2;
			}
			
			List<ReleaseIteration> releaseIterationList = service.searchReleaseIterations(release);
			
			if(releaseIterationList == null || releaseIterationList.isEmpty())
				return new ResponseEntity<List<ReleaseIteration>>(HttpStatus.NOT_FOUND);
			
			session.setAttribute("releaseIterationList", releaseIterationList);
			
			return new ResponseEntity<List<ReleaseIteration>>(releaseIterationList, HttpStatus.OK);
		}
			
		return new ResponseEntity<List<ReleaseIteration>>(HttpStatus.BAD_REQUEST);

	}
	
	//Search ReleaseItems
	@RequestMapping(value="/search/items/{releaseId}", method=RequestMethod.GET)
	public ResponseEntity<List<ReleaseItem>> searchReleaseItem(@PathVariable String releaseId, HttpSession session){
		
		Release release = null;
		
		List<Release> releaseList = (List<Release>)session.getAttribute("releaseList");
		if(releaseList != null){
			
			for (Release release2 : releaseList) {
				if(release2.getId().equals(releaseId))
					release = release2;
			}
			
			List<ReleaseItem> releaseItemList = service.searchReleaseItems(release);
			
			if(releaseItemList == null || releaseItemList.isEmpty())
				return new ResponseEntity<List<ReleaseItem>>(HttpStatus.NOT_FOUND);
			
			session.setAttribute("releaseItemList", releaseItemList);
			
			return new ResponseEntity<List<ReleaseItem>>(releaseItemList, HttpStatus.OK);
		}
			
		return new ResponseEntity<List<ReleaseItem>>(HttpStatus.BAD_REQUEST);

	}
	
	
	
	/*Manage Release*/
	//Adding new Release
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public ResponseEntity<Release> addNewRelease(@RequestBody Release release, HttpSession session){
		
		User user = (User)session.getAttribute("user");
		
		//if user has not logged in or release object is empty
		if(user == null || release == null)
			return new ResponseEntity<Release>(HttpStatus.BAD_REQUEST);
		
		//Adding createdBy and createdDate fields to release
		release.setCreatedBy(user.getFirstName().concat(user.getLastName()));
		release.setCreatedDate(new Date());
		
		ReleaseLog releaseLog = new ReleaseLog(Utility.getUUID(), user.getFirstName().concat(user.getLastName()), new Date(), release);
		
		Release newRelease = service.addRelease(release, releaseLog);
		
		return new ResponseEntity<Release>(newRelease, HttpStatus.OK);
	}
	
	//Adding ItemToRelease
	@RequestMapping(value="/add/item", method=RequestMethod.POST)
	public ResponseEntity<Release> addNewReleaseItem(@RequestBody ReleaseItem  releaseItem, HttpSession session){
		
		User user = (User)session.getAttribute("user");
		
		//if user has not logged in or releaseItem object is empty
		if(user == null || releaseItem == null)
			return new ResponseEntity<Release>(HttpStatus.BAD_REQUEST);
		
		releaseItem.getItem().setCreatedBy(user.getFirstName().concat(user.getLastName()));
		releaseItem.getItem().setCreatedDate(new Date());
		
		ItemLog itemLog = new ItemLog(Utility.getUUID(), releaseItem.getItem(), new Date(), user.getFirstName().concat(user.getLastName()));
		
		Release release = service.addItemToRelease(releaseItem, itemLog);
		
		return new ResponseEntity<Release>(release, HttpStatus.OK);
	}
	
	//Updating Release
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public ResponseEntity<Release> updateRelease(@RequestBody Release release, HttpSession session){
		
		User user = (User)session.getAttribute("user");
		
		//if user has not logged in or release object is empty
		if(user == null || release == null)
			return new ResponseEntity<Release>(HttpStatus.BAD_REQUEST);
		
		ReleaseLog releaseLog = new ReleaseLog(Utility.getUUID(), user.getFirstName().concat(user.getLastName()), new Date(), release);
		
		Release newRelease = service.updateRelease(release, releaseLog);
		
		return new ResponseEntity<Release>(newRelease, HttpStatus.OK);
	}

	//Updating Release
	@RequestMapping(value="/delete/{releaseId}", method=RequestMethod.PUT)
	public ResponseEntity<Release> deleteRelease(@PathVariable String releaseId, HttpSession session){
		
		User user = (User)session.getAttribute("user");
		
		if(user == null)
			return new ResponseEntity<Release>(HttpStatus.BAD_REQUEST);
		
		List<Release> releaseList = (List<Release>)session.getAttribute("releaseList");
		
		if(releaseList == null || releaseList.isEmpty())
			return new ResponseEntity<Release>(HttpStatus.BAD_REQUEST);
		Release release = null;
		for (Release release2 : releaseList) {
			if(release2.getId().equals(releaseId))
				release = release2;
		}
		
		//Deleting Release from db
		release = service.deleteRelease(release);
		
		return new ResponseEntity<Release>(release, HttpStatus.OK);
		
		
	}

}
