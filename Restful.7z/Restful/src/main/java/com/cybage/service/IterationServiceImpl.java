package com.cybage.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.dao.IterationDao;
import com.cybage.model.ItemLog;
import com.cybage.model.Iteration;
import com.cybage.model.IterationItem;
import com.cybage.model.IterationLog;
import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseIteration;

@Service
public class IterationServiceImpl implements IterationService {

	@Autowired
	private IterationDao dao; 
	
	/*List Iteration*/
	@Override
	public List<Iteration> getAllIterations() {
		
		return dao.getAllIterations();
	}

	@Override
	public List<IterationItem> getAllIterationsWithItems() {
		
		return dao.getAllIterationsWithItems();
	}

	
	/*Search iterations by status, type, dates*/
	@Override
	public List<Iteration> searchIterationByStatus(IterationStatus iterationStatus) {
		
		return dao.searchIterationByStatus(iterationStatus);
	}

	@Override
	public List<Iteration> searchIterationByType(IterationType iterationType) {
		
		return dao.searchIterationByType(iterationType);
	}

	@Override
	public List<Iteration> searchIterationByDates(Date startDate, Date endDate) {
		
		return dao.searchIterationByDates(startDate, endDate);
	}

	@Override
	public List<Iteration> searchIterationByTitle(String title) {
		
		return dao.searchIterationByTitle(title);
	}

	@Override
	public List<IterationItem> searchIterationItems(Iteration iteration) {

		return dao.searchIterationItems(iteration);
	}
	
	

	/*Manage Iteration*/
	@Override
	public Iteration addIteration(ReleaseIteration releaseIteration, IterationLog iterationLog) {
		
		return dao.addIteration(releaseIteration, iterationLog);
	}

	@Override
	public Iteration updateIteration(Iteration iteration, IterationLog iterationLog) {

		return dao.updateIteration(iteration, iterationLog);
	}

	@Override
	public Iteration deleteIterationById(String id) {
		
		return dao.deleteIterationById(id);
	}

	@Override
	public Iteration deleteItertion(Iteration iteration) {
		
		return dao.deleteItertion(iteration);
	}

	@Override
	public IterationItem addItemToIteration(IterationItem iterationItem, ItemLog itemLog) {
		
		return dao.addItemToIteration(iterationItem, itemLog);
	}

}
