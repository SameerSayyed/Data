package com.cybage.service;

import java.util.Date;
import java.util.List;

import com.cybage.model.ItemLog;
import com.cybage.model.Release;
import com.cybage.model.ReleaseItem;
import com.cybage.model.ReleaseIteration;
import com.cybage.model.ReleaseLog;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;

public interface ReleaseService {
	/*List Release*/
	List<Release> getAllReleases();
	List<Release> getAllReleases(User user);
	List<ReleaseIteration> getAllReleasesWithIterations();
	List<ReleaseIteration> getAllReleasesWithIterations(User user);
	List<ReleaseItem> getAllReleseWithItems();
	List<ReleaseItem> getAllReleseWithItems(User user);
	
	/*Search Releases by type, status, by title, dates*/
	List<Release> searchReleaseByType(ReleaseType releaseType);
	List<Release> searchReleaseByStatus(ReleaseStatus releaseStatus);
	List<Release> searchReleaseByTitle(String title);
	List<Release> searchReleaseByDate(Date startDate, Date endDate);
	
	List<ReleaseIteration> searchReleaseIterations(Release release);
	List<ReleaseItem> searchReleaseItems(Release release);
	
	/*Manage Release*/
	Release addRelease(Release release, ReleaseLog releaseLog);
	Release addReleaseWithIteration(ReleaseIteration releaseIteration, ReleaseLog releaseLog);
	Release addItemToRelease(ReleaseItem releaseItem, ItemLog itemLog);
	Release updateRelease(Release release, ReleaseLog releaseLog);
	Release deleteRelease(Release release);
}
