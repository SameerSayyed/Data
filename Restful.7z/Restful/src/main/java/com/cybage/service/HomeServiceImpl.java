package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.dao.HomeDao;
import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.model.UserRole;
import com.cybage.utility.AESencrypt;
import com.cybage.utility.Utility;

@Service
public class HomeServiceImpl implements HomeService {

	@Autowired
	private HomeDao dao;
	
	public HomeServiceImpl() {
		System.out.println("HomeServiceImpl Ctor");
	}
	
	//Validate user - returns valid user on success, null on failure 
	@Override
	public User validateUser(User user) {
		//Encrypting user Password
		user.setPassword(AESencrypt.encrypt(user.getPassword()));
		
		//validating user through dao
		UserRole userRole = dao.validateLogin(user);
		if(userRole != null)
			return userRole.getUser();
		return null;
	}

	/*Getters for all Release reference Data*/
	
	@Override
	public List<ReleaseType> getAllReleaseTypes() {
		
		return dao.getAllReleaseTypes();
	}

	@Override
	public List<ReleaseStatus> getAllReleaseStatuses() {

		return dao.getAllReleaseStatuses();
	}

	@Override
	public List<ReleaseTo> getAllReleaseTos() {
		
		return dao.getAllReleaseTos();
	}

	/*Getters for all Iteration reference Data*/
	
	@Override
	public List<IterationStatus> getAllIterationStatuses() {
		
		return dao.getAllIterationStatuses();
	}

	@Override
	public List<IterationType> getAllItearationTypes() {
		
		return dao.getAllItearationTypes();
	}
	
}
