package com.cybage.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.model.UserRole;

@Repository
@Transactional
@SuppressWarnings("unchecked")
public class HomeDaoImpl implements HomeDao {

	@Autowired
	private SessionFactory factory;
	
	public HomeDaoImpl() {
		System.out.println("HomeDaoImpl Ctor");
	}

	@Override
	public UserRole validateLogin(User user) {
		Session session = factory.getCurrentSession();
		UserRole userRole = null;
		//Validating user
		LogicalExpression validationExpr = Restrictions
				.and(Restrictions.eq("email", user.getEmail()), Restrictions.eq("password", user.getPassword()));
		
		User validUser = (User)session.createCriteria(User.class)
				.add(validationExpr).uniqueResult();
		
		if(validUser != null)
			userRole = (UserRole)session.createCriteria(UserRole.class)
					.add(Restrictions.eq("user", validUser)).uniqueResult();
		
		return userRole;
	}

	
	/*Getters for all Release reference Data*/
	@Override
	public List<ReleaseType> getAllReleaseTypes() {
		
		return factory.getCurrentSession().createCriteria(ReleaseType.class).list();
	}

	
	@Override
	public List<ReleaseStatus> getAllReleaseStatuses() {
		
		return factory.getCurrentSession().createCriteria(ReleaseStatus.class).list();
	}

	
	@Override
	public List<ReleaseTo> getAllReleaseTos() {
		
		return factory.getCurrentSession().createCriteria(ReleaseTo.class).list();
	}

	
	
	/*Getters for all Iteration reference Data*/
	
	@Override
	public List<IterationStatus> getAllIterationStatuses() {
		
		return factory.getCurrentSession().createCriteria(IterationStatus.class).list();
	}

	@Override
	public List<IterationType> getAllItearationTypes() {

		return factory.getCurrentSession().createCriteria(IterationType.class).list();
	}
}
