package com.cybage.dao;

import java.util.List;

import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.model.UserRole;

public interface HomeDao {
	
	//Logging in
	UserRole validateLogin(User user);
	
	/*Getters for all Release reference Data*/
	List<ReleaseType> getAllReleaseTypes();
	List<ReleaseStatus> getAllReleaseStatuses();
	List<ReleaseTo> getAllReleaseTos();
	
	/*Getters for all Iteration reference Data*/
	List<IterationStatus> getAllIterationStatuses();
	List<IterationType> getAllItearationTypes();
	
}
