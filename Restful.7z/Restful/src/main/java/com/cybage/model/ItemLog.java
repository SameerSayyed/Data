package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name="itemslog")
public class ItemLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@ManyToOne
	@JoinColumn(name="ITEMID", referencedColumnName = "ID")
	private Item item;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="MODIFIEDDT")
	private Date modifiedDate;

	@Column(name="MODIFIEDBY", length=36)
	private String modifiedBy;
	
	
	public ItemLog() {	
	}

	public ItemLog(String id, Item item, Date modifiedDate, String modifiedBy) {
		super();
		this.id = id;
		this.item = item;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Item getItem() {
		return this.item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	@Override
	public String toString() {
		return "ItemLog [id=" + id + ", item=" + item + ", modifiedDate=" + modifiedDate + ", modifiedBy=" + modifiedBy
				+ "]";
	}
	
}