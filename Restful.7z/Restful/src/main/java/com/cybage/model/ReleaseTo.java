package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="releaseto")
public class ReleaseTo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@Column(name="NAME", length=45)
	private String name;

	
	public ReleaseTo() {
	}

	public ReleaseTo(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	@Override
	public String toString() {
		return "ReleaseTo [id=" + id + ", name=" + name + "]";
	}

}