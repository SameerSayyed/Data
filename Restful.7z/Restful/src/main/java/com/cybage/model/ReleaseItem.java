package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="releaseitems")
public class ReleaseItem implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@ManyToOne
	@JoinColumn(name="ITEMID", referencedColumnName = "ID")
	private Item item;

	@ManyToOne
	@JoinColumn(name="RELEASEID", referencedColumnName = "ID")
	private Release release;

	public ReleaseItem() {
	}

	public ReleaseItem(String id, Item item, Release release) {
		super();
		this.id = id;
		this.item = item;
		this.release = release;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Item getItem() {
		return this.item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Release getRelease() {
		return this.release;
	}

	public void setRelease(Release release) {
		this.release = release;
	}

	@Override
	public String toString() {
		return "ReleaseItem [id=" + id + ", item=" + item + ", release=" + release + "]";
	}

}