package com.cybage.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.model.Role;
import com.cybage.model.User;
import com.cybage.model.UserRole;
import com.cybage.service.HomeService;
import com.cybage.utility.Utility;

@Controller
@RequestMapping("/home")
public class HomeController {
	
	@Autowired
	HomeService service;
	
	public HomeController() {
		System.out.println("Home Controller Ctor");
	}
	
	
	/*Home Page Redirection*/
	@RequestMapping(value="/home")
	public String showHomePage()
	{
		System.out.println("In showHomePage");
		return "Home";
	}
	
	@RequestMapping(value = "/aboutus")
	public String showAboutUsPage(){
		System.out.println("In showAboutUsPage");
		return "AboutUs";
	}
	
	@RequestMapping(value = "iteration")
	public String showIterartionPage(){
		return "redirect:/iteration/home";
	}
	
	@RequestMapping(value = "/save")
	public String saveData(){
		
		Role role = new Role();
		role.setId(Utility.getUUID());
		role.setName("Manager");
		
		User user = new User();
		user.setId(Utility.getUUID());
		user.setFirstName("UserFirst");
		user.setLastName("User Last");
		user.setEmail("user@gmail.com");
		user.setPassword("userPassword");
		
		UserRole userRole = new UserRole();
		userRole.setId(Utility.getUUID());
		userRole.setUser(user);
		userRole.setRole(role);
		
		System.out.println("Before Saving: \n\n User : " + user + "\n\n Role: " + role + "\n\n USerRole : " + userRole);
		System.out.println("Ids: \n\n userid" + user.getId().length() + "\n\nRole : " + role.getId().length() + "\n\nUserRole : " + userRole.getId().length());
		//Save userRole
		System.out.println("User Role Entered with id : " + service.saveUser(userRole));
		
		return "Home";
	}

	
	@RequestMapping(value = "/getUser")
	public String showUser(){
		System.out.println("user: " + service.getUser("3f602a37-e7c8-4e6c-b120-06b2f1fba590"));
		return "AboutUs";
	}
	
	@RequestMapping(value = "/referenceData")
	public String addReferenceData(){
		
		/*Adding User Reference Data*/
		List<UserRole> userRoles = new ArrayList<UserRole>();
		
		List<Role> roles = new ArrayList<Role>();
		roles.add(new Role(Utility.getUUID(), "Project Manager"));
		roles.add(new Role(Utility.getUUID(), "Release Manager"));
		 
		userRoles.add(new UserRole(Utility.getUUID(), new Role("", "Project Manager"), new User(Utility.getUUID(), "Sameer", "Sayyed", "sameersa@cybage.com", "sameer123")));
		userRoles.add(new UserRole(Utility.getUUID(), new Role("", "Release Manager"), new User(Utility.getUUID(), "Rashmi", "Khollam", "rashmikh@cybage.com", "rashmi123")));
		/*userRoles.add(new UserRole(Utility.getUUID(), new Role(Utility.getUUID(), "Release Manager"), new User(Utility.getUUID(), "Rishabh", "Trivedi", "rishabht@cybage.com", "rishabh123")));
		userRoles.add(new UserRole(Utility.getUUID(), new Role(Utility.getUUID(), "Project Manager"), new User(Utility.getUUID(), "Ritesh", "Chaudhari", "riteshch@cybage.com", "ritesh123")));*/
		for (UserRole userRole : userRoles) {
			service.saveUser(userRole);
		}
		
		/*Adding Release Reference Data*/
		//releaseTypes
		List<ReleaseType> releaseTypes = new ArrayList<ReleaseType>();
		releaseTypes.add(new ReleaseType(Utility.getUUID(), "MileStone"));
		releaseTypes.add(new ReleaseType(Utility.getUUID(), "Build"));
		releaseTypes.add(new ReleaseType(Utility.getUUID(), "Major"));
		releaseTypes.add(new ReleaseType(Utility.getUUID(), "Minor"));
		releaseTypes.add(new ReleaseType(Utility.getUUID(), "Final"));
		
		for (ReleaseType releaseType : releaseTypes) {
			service.addReleaseType(releaseType);
		}
		
		//ReleaseTo
		List<ReleaseTo> releaseTos = new ArrayList<ReleaseTo>();
		releaseTos.add(new ReleaseTo(Utility.getUUID(), "Dev Test"));
		releaseTos.add(new ReleaseTo(Utility.getUUID(), "QA Test"));
		releaseTos.add(new ReleaseTo(Utility.getUUID(), "Stage"));
		releaseTos.add(new ReleaseTo(Utility.getUUID(), "Production"));
		
		for (ReleaseTo releaseTo : releaseTos) {
			service.addReleaseToData(releaseTo);
		}
		
		
		//ReleaseStatus
		List<ReleaseStatus> releaseStatus = new ArrayList<ReleaseStatus>();
		releaseStatus.add(new ReleaseStatus(Utility.getUUID(), "Planned"));
		releaseStatus.add(new ReleaseStatus(Utility.getUUID(), "Released"));
		releaseStatus.add(new ReleaseStatus(Utility.getUUID(), "Delayed"));
		releaseStatus.add(new ReleaseStatus(Utility.getUUID(), "Suspended"));
		releaseStatus.add(new ReleaseStatus(Utility.getUUID(), "Resumed"));
		
		for (ReleaseStatus releaseStatus2 : releaseStatus) {
			service.addReleaseStatus(releaseStatus2);
		}
		
		/*Adding Iteration Reference Data*/
		//IterationStatus
		List<IterationStatus> iterationStatus = new ArrayList<IterationStatus>();
		iterationStatus.add(new IterationStatus(Utility.getUUID(), "Planned"));
		iterationStatus.add(new IterationStatus(Utility.getUUID(), "Working"));
		iterationStatus.add(new IterationStatus(Utility.getUUID(), "Completed"));
		
		for (IterationStatus iterationStatus2 : iterationStatus) {
			service.addIterationStatus(iterationStatus2);
		}
		
		//IterationType
		List<IterationType> iterationTypes = new ArrayList<IterationType>();
		iterationTypes.add(new IterationType(Utility.getUUID(), "Dev"));
		iterationTypes.add(new IterationType(Utility.getUUID(), "QA"));
		iterationTypes.add(new IterationType(Utility.getUUID(), "Planning"));
		iterationTypes.add(new IterationType(Utility.getUUID(), "Release"));
		iterationTypes.add(new IterationType(Utility.getUUID(), "Regression"));
		
		for (IterationType iterationType : iterationTypes) {
			service.addIteraionType(iterationType);
		}
		
		
		return "AboutUs";
	}
}
