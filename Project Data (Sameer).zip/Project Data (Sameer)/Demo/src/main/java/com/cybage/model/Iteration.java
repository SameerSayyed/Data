package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="iteration")
public class Iteration implements Serializable {
	private static final long serialVersionUID = 1L;


	@Id
	private String id;
	
	@Column(name="TITLE", length=45)
	private String title;
	
	@Column(name="DESCRIPTION", length=100)
	private String description;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="STARTDT")
	private Date startDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ENDDT")
	private Date endDate;
	
	//bi-directional many-to-one association to IterationStatus
	@ManyToOne
	@JoinColumn(name="STATUSID", referencedColumnName = "ID")
	private IterationStatus iterationStatus;

	//bi-directional many-to-one association to IterationType
	@ManyToOne
	@JoinColumn(name="TYPEID", referencedColumnName = "ID")
	private IterationType iterationType;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATEDDT")
	private Date createdDate;

	
	@Column(name="CREATEDBY", length=36)
	private String createdBy;

	
	public Iteration() {
	}

	public Iteration(String id, String title, String description, Date startDate, Date endDate,
			IterationStatus iterationStatus, IterationType iterationType) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.iterationStatus = iterationStatus;
		this.iterationType = iterationType;
	}

	public Iteration(String id, String title, String description, Date startDate, Date endDate,
			IterationStatus iterationStatus, IterationType iterationType, Date createdDate, String createdBy) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.iterationStatus = iterationStatus;
		this.iterationType = iterationType;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public IterationStatus getIterationStatus() {
		return this.iterationStatus;
	}

	public void setIterationStatus(IterationStatus iterationStatus) {
		this.iterationStatus = iterationStatus;
	}

	public IterationType getIterationType() {
		return this.iterationType;
	}

	public void setIterationType(IterationType iterationType) {
		this.iterationType = iterationType;
	}

	

	@Override
	public String toString() {
		return "Iteration [id=" + id + ", title=" + title + ", description=" + description + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", iterationStatus=" + iterationStatus + ", iterationType=" + iterationType
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy + "]";
	}

}