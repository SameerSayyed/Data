package com.cybage.service;

import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.model.UserRole;

public interface HomeService {
	
	String saveUser(UserRole userRole);
	User getUser(String id);
	
	//Adding Release Reference Data
	void addReleaseToData(ReleaseTo releaseTo);
	
	void addReleaseStatus(ReleaseStatus releaseStatus);
	
	void addReleaseType(ReleaseType releaseType);
	
	
	//Adding Iteration Reference Data
	void addIterationStatus(IterationStatus iterationStatus);
	
	void addIteraionType(IterationType iterationType);
}
