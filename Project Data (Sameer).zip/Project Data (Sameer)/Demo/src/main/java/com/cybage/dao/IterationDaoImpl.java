package com.cybage.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.cybage.model.Iteration;
import com.cybage.model.IterationLog;
import com.cybage.model.ReleaseIteration;

@Transactional
@Repository
public class IterationDaoImpl implements IterationDao {
	
	@Autowired
	private SessionFactory factory;
	
	//Add new Iteration record into iteration table Using Methods
	@Override
	public Iteration addIteration(ReleaseIteration releaseIteration, IterationLog iterationLog) {
		Session session = factory.getCurrentSession();
		
		//Adding Iteration in Iteration table
		session.save(releaseIteration.getIteration());
			
		//Adding Iteration in Release-Iteration link table
		session.save(releaseIteration);
		
		//Adding Log to IterationLog table
		session.save(iterationLog);
		
		
		return releaseIteration.getIteration();
		
	}

	//Update existing Iteration Details Using Methods
	@Override
	public Iteration updateIteration(Iteration iteration, IterationLog iterationLog) {
		Session session = factory.getCurrentSession();
		
		//Updating iteration Table
		session.update(iteration);
		
		//Adding Log to IterationLog Table
		session.save(iterationLog);
		
		return iteration;
	}
	
	//Delete Iteration Record From Db by id Using HQL
	@Override
	public Iteration deleteIterationById(String id) {
		Session session = factory.getCurrentSession();
		
		Iteration iteration = (Iteration) session.createQuery("SELECT i FROM Iteration i WHERE id=:it")
				.setParameter("it", id).uniqueResult();
		
		//Checking for availability of iteration with given id
		if(iteration != null){
			
			//Deleting iteration from Release-Iteration link table
			session.createQuery("DELETE FROM ReleaseIteration WHERE iteration=:iterate")
				.setParameter("iterate", iteration).executeUpdate();
			
			//Deleting iteration from IterationLog Table
			
			session.createQuery("DELETE FROM IterationLog WHERE iteration=:iterate")
				.setParameter("iterate", iteration).executeUpdate();
			
			//Deleting iteration from iteration table
			factory.getCurrentSession().delete(iteration);
			
			return iteration;
		}
		return null;
	}

	//Delete Iteration from db by iteration pojo
	@Override
	public Iteration deleteItertion(Iteration iteration) {
		Session session = factory.getCurrentSession();
		
		//Deleting iteration from Release-Iteration link table
		session.createQuery("DELETE FROM ReleaseIteration WHERE iteration=:iterat")
			.setParameter("iterat", iteration).executeUpdate();
		
		//Deleting logs related to this iteration from IterationLog table
		session.createQuery("DELETE FROM IterationLog WHERE iteration=:iterate")
			.setParameter("iterate", iteration).executeUpdate();
		
		//Deleting iteration from iteration table
		factory.getCurrentSession().delete(iteration);
		
		return iteration;
	}

}
