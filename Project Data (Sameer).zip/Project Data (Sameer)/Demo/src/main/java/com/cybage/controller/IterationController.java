package com.cybage.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cybage.dao.IterationDao;
import com.cybage.model.Iteration;
import com.cybage.model.IterationLog;
import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.Release;
import com.cybage.model.ReleaseIteration;
import com.cybage.utility.Utility;

@Controller
@RequestMapping("iteration")
public class IterationController {
	
	@Autowired
	private IterationDao dao;
	
	public IterationController() {
		System.out.println("In IterationController");
	}
	
	@RequestMapping(value = "home")
	public String showIterationHome(){
		return "Iteration";
	}
	
	@RequestMapping(value = "iterationTest")
	public String iterationTest(){
		//Creating Dummy Iteration
		IterationStatus iterationStatus = new IterationStatus("", "");
		IterationType iterationType = new IterationType(id, name);
		Iteration iteration = new 
				Iteration(Utility.getUUID(), "Test Iteration", "Test Description", new Date(), new Date(), iterationStatus, iterationType);
		
		//Creating Dummy Release
		Release release = new 
				Release(id, title, description, startDate, plannedDate, releaseDate, releaseType, releaseTo, releaseStatus, manager, version);
		
		//Creating ReleaseIteration
		ReleaseIteration releaseIteration = new 
				ReleaseIteration(Utility.getUUID(), iteration, release);
		
		//Creating IterationLog
		IterationLog iterationLog = new 
				IterationLog(Utility.getUUID(), iteration, new Date(), modifiedBy);
		
		dao.addIteration(releaseIteration, iterationLog);
		
		
		return "Iteration";
	}
}
