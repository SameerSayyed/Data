package com.cybage.service;

import com.cybage.model.User;

public interface HomeService {
	

}
