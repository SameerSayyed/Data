package com.cybage.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.dao.ReleaseDao;
import com.cybage.model.ItemLog;
import com.cybage.model.Release;
import com.cybage.model.ReleaseItem;
import com.cybage.model.ReleaseIteration;
import com.cybage.model.ReleaseLog;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;

@Service
public class ReleaseServiceImpl implements ReleaseService {

	@Autowired
	ReleaseDao dao;
	
	public ReleaseServiceImpl() {
		System.out.println("Release Service");
	}
	
	@Override
	public List<Release> getAllReleases() {
		return dao.getAllReleases();
	}

	@Override
	public List<Release> getAllReleases(User user) {
		
		return dao.getAllReleases(user);
	}

	@Override
	public List<ReleaseIteration> getAllReleasesWithIterations() {
		
		return dao.getAllReleasesWithIterations();
	}

	@Override
	public List<ReleaseIteration> getAllReleasesWithIterations(User user) {
		
		return dao.getAllReleasesWithIterations(user);
	}

	@Override
	public List<ReleaseItem> getAllReleseWithItems() {
		
		return dao.getAllReleseWithItems();
	}

	@Override
	public List<ReleaseItem> getAllReleseWithItems(User user) {

		return dao.getAllReleseWithItems(user);
	}

	@Override
	public List<Release> searchReleaseByType(ReleaseType releaseType) {
		
		return dao.searchReleaseByType(releaseType);
	}

	@Override
	public List<Release> searchReleaseByStatus(ReleaseStatus releaseStatus) {
		
		return dao.searchReleaseByStatus(releaseStatus);
	}

	@Override
	public List<Release> searchReleaseByTitle(String title) {
		
		return dao.searchReleaseByTitle(title);
	}

	@Override
	public List<Release> searchReleaseByStartDate(Date startDate, Date endDate) {
	
		return dao.searchReleaseByStartDate(startDate, endDate);
	}

	@Override
	public List<Release> serachReleaseByPlannedDate(Date startDate, Date endDate) {
		
		return dao.serachReleaseByPlannedDate(startDate, endDate);
	}

	@Override
	public List<Release> searchReleaseByReleasedDate(Date startDate, Date endDate) {
		
		return dao.searchReleaseByReleasedDate(startDate, endDate);
	}

	@Override
	public List<ReleaseIteration> searchReleaseIterations(Release release) {
		
		return dao.searchReleaseIterations(release);
	}

	@Override
	public List<ReleaseItem> searchReleaseItems(Release release) {
		
		return dao.searchReleaseItems(release);
	}

	@Override
	public Release addRelease(Release release, ReleaseLog releaseLog) {
		
		return dao.addRelease(release, releaseLog);
	}

	@Override
	public Release addReleaseWithIteration(ReleaseIteration releaseIteration, ReleaseLog releaseLog) {

		return dao.addReleaseWithIteration(releaseIteration, releaseLog);
	}

	@Override
	public Release addItemToRelease(ReleaseItem releaseItem, ItemLog itemLog) {
		
		return dao.addItemToRelease(releaseItem, itemLog);
	}

	@Override
	public Release updateRelease(Release release, ReleaseLog releaseLog) {
		
		return dao.updateRelease(release, releaseLog);
	}

	@Override
	public Release deleteRelease(Release release) {

		return dao.deleteRelease(release);
	}

}
