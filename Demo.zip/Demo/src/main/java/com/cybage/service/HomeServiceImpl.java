package com.cybage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.dao.HomeDao;
import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.model.UserRole;
import com.cybage.utility.AESencrypt;

@Service
public class HomeServiceImpl implements HomeService {

	@Autowired
	private HomeDao dao;
	
	public HomeServiceImpl() {
		System.out.println("HomeServiceImpl Ctor");
	}

	@Override
	public String saveUser(UserRole userRole) {
		
		userRole.getUser().setPassword(AESencrypt.encrypt(userRole.getUser().getPassword()));
		
		return dao.saveUser(userRole);
	}

	@Override
	public User getUser(String id) {
		
		return dao.getUser(id);
	}

	@Override
	public void addReleaseToData(ReleaseTo releaseTo) {
		dao.addReleaseToData(releaseTo);
		
	}

	@Override
	public void addReleaseStatus(ReleaseStatus releaseStatus) {
		dao.addReleaseStatus(releaseStatus);
		
	}

	@Override
	public void addReleaseType(ReleaseType releaseType) {
		dao.addReleaseType(releaseType);
		
	}

	@Override
	public void addIterationStatus(IterationStatus iterationStatus) {
		dao.addIterationStatus(iterationStatus);
		
	}

	@Override
	public void addIteraionType(IterationType iterationType) {
		dao.addIteraionType(iterationType);
		
	}
	

}
