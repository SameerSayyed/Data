package com.cybage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.dao.HomeDao;
import com.cybage.model.User;

@Service
public class HomeServiceImpl implements HomeService {

	@Autowired
	private HomeDao dao;
	
	public HomeServiceImpl() {
		System.out.println("HomeServiceImpl Ctor");
	}
	
	

}
