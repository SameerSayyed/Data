package com.cybage.dao;

import java.util.List;

import com.cybage.model.ItemLog;
import com.cybage.model.Release;
import com.cybage.model.ReleaseItem;
import com.cybage.model.ReleaseIteration;
import com.cybage.model.ReleaseLog;

public interface ReleaseDao {
	
	Release addRelease(Release release, ReleaseLog releaseLog);
	Release addReleaseWithIteration(ReleaseIteration releaseIteration, ReleaseLog releaseLog);
	Release addItemToRelease(ReleaseItem releaseItem, ItemLog itemLog);
	Release updateRelease(Release release, ReleaseLog releaseLog);
	Release delteReleaseById(String id);
	Release deleteRelease(Release release);
}
