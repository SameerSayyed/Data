package com.cybage.dao;

import com.cybage.model.User;

public interface HomeDao {
	
	
}
