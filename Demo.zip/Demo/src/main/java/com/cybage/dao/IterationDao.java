package com.cybage.dao;

import com.cybage.model.ItemLog;
import com.cybage.model.Iteration;
import com.cybage.model.IterationItem;
import com.cybage.model.IterationLog;
import com.cybage.model.ReleaseIteration;

public interface IterationDao {
	
	Iteration addIteration(ReleaseIteration releaseIteration, IterationLog iterationLog);
	Iteration updateIteration(Iteration iteration, IterationLog iterationLog);
	Iteration deleteIterationById(String id);
	Iteration deleteItertion(Iteration iteration);
	
	IterationItem addIterationItem(IterationItem iterationItem, ItemLog itemLog);
}
