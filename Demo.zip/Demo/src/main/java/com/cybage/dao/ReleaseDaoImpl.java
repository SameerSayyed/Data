package com.cybage.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.ItemLog;
import com.cybage.model.Release;
import com.cybage.model.ReleaseItem;
import com.cybage.model.ReleaseIteration;
import com.cybage.model.ReleaseLog;

@Repository
@Transactional
public class ReleaseDaoImpl implements ReleaseDao {

	@Autowired
	SessionFactory factory;
	
	//Adding Release
	@Override
	public Release addRelease(Release release, ReleaseLog releaseLog) {
		Session session = factory.getCurrentSession();
		
		//Adding Release to Release Table
		session.save(release);
		
		//Adding Log to ReleaseLog Table
		session.save(releaseLog);
		
		return release;
	}
	
	//Adding Item to existing Release
	@Override
	public Release addItemToRelease(ReleaseItem releaseItem, ItemLog itemLog) {
		Session session = factory.getCurrentSession();
		
		//Adding Item to Items table
		session.save(releaseItem.getItem());
		
		//Adding ReleaseItem to ReleaseItem Link Table
		session.save(releaseItem);
		
		//Adding Log to ItemsLog Table
		session.save(itemLog);
		
		return releaseItem.getRelease();
	}
	
	//Adding Release with Iteration
	@Override
	public Release addReleaseWithIteration(ReleaseIteration releaseIteration, ReleaseLog releaseLog) {
		Session session = factory.getCurrentSession();
		
		//Adding Release to ReleaseTable
		session.save(releaseIteration.getRelease());
		
		//Adding Iteration to IterationTable
		session.save(releaseIteration.getIteration());
		
		//Adding Release ana Iteration to ReleaseIteration Link Table
		session.save(releaseIteration);
		
		//Adding Log to ReleaseLog Table
		session.save(releaseLog);
		
		
		return releaseIteration.getRelease();
	}

	

	@Override
	public Release updateRelease(Release release, ReleaseLog releaseLog) {
		Session session = factory.getCurrentSession();
		
		//Updating Release in Release Table
		session.update(release);
		
		//Adding Log to releaseLog Table
		session.save(releaseLog);
		
		return null;
	}

	@Override
	public Release delteReleaseById(String id) {
		return null;
	}

	@Override
	public Release deleteRelease(Release release) {
		return null;
	}

	



	

}
