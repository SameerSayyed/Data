package com.cybage.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.User;

@Repository
@Transactional
public class HomeDaoImpl implements HomeDao {

	@Autowired
	private SessionFactory factory;
	
	public HomeDaoImpl() {
		System.out.println("HomeDaoImpl Ctor");
	}
	
		
}
