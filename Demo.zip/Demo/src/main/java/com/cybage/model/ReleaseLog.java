package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="releaselog")
public class ReleaseLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@Column(name="MODIFIEDBY", length=36)
	private String modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="MODIFIEDDT")
	private Date modifiedDate;

	//bi-directional many-to-one association to Release
	@ManyToOne
	@JoinColumn(name="RELEASEID", referencedColumnName = "ID")
	private Release release;

	public ReleaseLog() {
	}

	public ReleaseLog(String id, String modifiedBy, Date modifiedDate, Release release) {
		super();
		this.id = id;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.release = release;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Release getRelease() {
		return this.release;
	}

	public void setRelease(Release release) {
		this.release = release;
	}

	@Override
	public String toString() {
		return "ReleaseLog [id=" + id + ", modifiedBy=" + modifiedBy + ", modifiedDate=" + modifiedDate + ", release="
				+ release + "]";
	}

}