package com.cybage.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import com.cybage.utility.Utility;


@Entity
@Table(name = "roles")
public class Role implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	private String id;
	
	@Column(name = "NAME", length = 45, nullable = false, unique = true)
	private String name;
	
	//bi-directional many-to-one association to Userrole
	@OneToMany(mappedBy="role", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	private List<UserRole> userRole;
	
	//default constructor
	public Role() {
	}
	
	//parameterized constructor
	public Role(String name, List<UserRole> userRole) {
		this.id = Utility.getUUID();
		this.name = name;
		this.userRole = userRole;
	}
	
	//Getter Setter
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<UserRole> getUserRole() {
		return userRole;
	}

	public void setUserRole(List<UserRole> userRole) {
		this.userRole = userRole;
	}
	
	
}
