package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;

import com.cybage.utility.Utility;

import java.util.List;


@Entity
@Table(name="iterationtype")
public class IterationType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@Column(name="NAME", length=45, nullable=false)
	private String name;

	//bi-directional many-to-one association to Iteration
	@OneToMany(mappedBy="iterationType", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<Iteration> iterations;

	//default constructor
	public IterationType() {
		this.id = Utility.getUUID();
	}
		
	//parameterized constructor
	public IterationType(String name, List<Iteration> iterations) {
		this.id = Utility.getUUID();
		this.name = name;
		this.iterations = iterations;
	}


	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Iteration> getIterations() {
		return this.iterations;
	}

	public void setIterations(List<Iteration> iterations) {
		this.iterations = iterations;
	}

	
}