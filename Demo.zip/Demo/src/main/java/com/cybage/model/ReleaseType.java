package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;

import com.cybage.utility.Utility;

import java.util.List;


/**
 * The persistent class for the releasetype database table.
 * 
 */
@Entity
@NamedQuery(name="ReleaseType.findAll", query="SELECT r FROM ReleaseType r")
public class ReleaseType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;
	
	@Column(name="NAME", length=45, nullable=false)
	private String name;

	//bi-directional many-to-one association to Release
	@OneToMany(mappedBy="releaseType", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<Release> releases;

	//default constructor
	public ReleaseType() {
		this.id = Utility.getUUID();
	}
	
	//parameterized constructor
	public ReleaseType(String name, List<Release> releases) {
		this.id = Utility.getUUID();
		this.name = name;
		this.releases = releases;
	}

	//Getter Setter
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Release> getReleases() {
		return this.releases;
	}

	public void setReleases(List<Release> releases) {
		this.releases = releases;
	}

	
}