package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;

import com.cybage.utility.Utility;


@Entity
@Table(name="releaseiteration")
public class ReleaseIteration implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	//bi-directional many-to-one association to Iteration
	@ManyToOne
	@JoinColumn(name="ITERATIONID", referencedColumnName = "ID")
	private Iteration iteration;

	//bi-directional many-to-one association to Release
	@ManyToOne
	@JoinColumn(name="RELEASEID", referencedColumnName = "ID")
	private Release release;
	
	//default constructor
	public ReleaseIteration() {
		this.id = Utility.getUUID();
	}

	//parameterized constructor
	public ReleaseIteration(Iteration iteration, Release release) {
		this.id = Utility.getUUID();
		this.iteration = iteration;
		this.release = release;
	}

	//Getter Setter
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Iteration getIteration() {
		return this.iteration;
	}

	public void setIteration(Iteration iteration) {
		this.iteration = iteration;
	}

	public Release getRelease() {
		return this.release;
	}

	public void setRelease(Release release) {
		this.release = release;
	}

}