package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;

import com.cybage.utility.Utility;

import java.util.List;


@Entity
@Table(name="releasestatus")
public class ReleaseStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;
	
	@Column(name="NAME", length=45, nullable=false)
	private String name;

	//bi-directional many-to-one association to Release
	@OneToMany(mappedBy="releaseStatus", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<Release> releases;
	
	//default constructor
	public ReleaseStatus() {
		this.id = Utility.getUUID();
	}
	
	//parameterized constructor
	public ReleaseStatus(String name, List<Release> releases) {
		this.id = Utility.getUUID();
		this.name = name;
		this.releases = releases;
	}

	//Getter Setter
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Release> getReleases() {
		return this.releases;
	}

	public void setReleases(List<Release> releases) {
		this.releases = releases;
	}

	
}