package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;

import com.cybage.utility.Utility;

import java.util.Date;
import java.util.List;


@Entity
@Table(name="iteration")
public class Iteration implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;
	
	@Column(name="TITLE", length=45, nullable=false, unique=true)
	private String title;
	
	@Column(name="DESCRIPTION", length=100)
	private String description;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="STARTDT", nullable=false)
	private Date startDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ENDDT")
	private Date endDate;
	
	//bi-directional many-to-one association to IterationStatus
	@ManyToOne
	@JoinColumn(name="STATUSID", referencedColumnName = "ID")
	private IterationStatus iterationstatus;

	//bi-directional many-to-one association to IterationType
	@ManyToOne
	@JoinColumn(name="TYPEID", referencedColumnName = "ID")
	private IterationType iterationType;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATEDDT", nullable=false)
	private Date createdDate;

	
	@Column(name="CREATEDBY", length=36, nullable=false)
	private String createdBy;

	//bi-directional many-to-one association to IterationItem
	@OneToMany(mappedBy="iteration", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<IterationItem> iterationItems;

	//bi-directional many-to-one association to IterationLog
	@OneToMany(mappedBy="iteration", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<IterationLog> iterationLogs;

	//bi-directional many-to-one association to ReleaseIteration
	@OneToMany(mappedBy="iteration", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<ReleaseIteration> releaseIterations;
	
	//default constructor
	public Iteration() {
		this.id = Utility.getUUID();
	}

	//parameterized constructor
	public Iteration(String title, String description, Date startDate, Date endDate, IterationStatus iterationstatus,
			IterationType iterationType, Date createdDate, String createdBy, List<IterationItem> iterationItems,
			List<IterationLog> iterationLogs, List<ReleaseIteration> releaseIterations) {
		this.id = Utility.getUUID();
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.iterationstatus = iterationstatus;
		this.iterationType = iterationType;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.iterationItems = iterationItems;
		this.iterationLogs = iterationLogs;
		this.releaseIterations = releaseIterations;
	}
	
	//Getter Setter
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public IterationStatus getIterationstatus() {
		return iterationstatus;
	}

	public void setIterationstatus(IterationStatus iterationstatus) {
		this.iterationstatus = iterationstatus;
	}

	public IterationType getIterationType() {
		return iterationType;
	}

	public void setIterationType(IterationType iterationType) {
		this.iterationType = iterationType;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public List<IterationItem> getIterationItems() {
		return iterationItems;
	}

	public void setIterationItems(List<IterationItem> iterationItems) {
		this.iterationItems = iterationItems;
	}

	public List<IterationLog> getIterationLogs() {
		return iterationLogs;
	}

	public void setIterationLogs(List<IterationLog> iterationLogs) {
		this.iterationLogs = iterationLogs;
	}

	public List<ReleaseIteration> getReleaseIterations() {
		return releaseIterations;
	}

	public void setReleaseIterations(List<ReleaseIteration> releaseIterations) {
		this.releaseIterations = releaseIterations;
	}
	
	

}