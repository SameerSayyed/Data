package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;

import com.cybage.utility.Utility;

import java.util.List;


@Entity
@Table(name="users")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id = Utility.getUUID();
	
	@Column(name="FIRSTNAME", length=45, nullable=false)
	private String firstName;
	
	@Column(name="LASTNAME", length=45)
	private String lastName;
	
	@Column(name="EMAIL", length=60, nullable=false, unique=true)
	private String email;
	
	@Column(name="PASSWORD", length=45, nullable=false)
	private String password;
	
	
	//bi-directional many-to-one association to UserRole
	@OneToMany(mappedBy="user", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<UserRole> userRole;
	
	//bi-directional many-to-one association to Release
	@OneToMany(mappedBy="manager", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<Release> releases;
	
	//default Constructor
	public User() {
	}
	
	//parameterized Constructor
	public User(String firstName, String lastName, String email, String password, List<UserRole> userRole,
			List<com.cybage.model.Release> releases) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.userRole = userRole;
		this.releases = releases;
	}

	//Getter Setter
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<UserRole> getUserRole() {
		return userRole;
	}

	public void setUserRole(List<UserRole> userRole) {
		this.userRole = userRole;
	}

	public List<Release> getReleases() {
		return releases;
	}

	public void setReleases(List<Release> releases) {
		this.releases = releases;
	}
	
	
	
	
	

}