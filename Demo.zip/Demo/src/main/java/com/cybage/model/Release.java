package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name="release")
public class Release implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@Column(name="TITLE", length=45)
	private String title;
	
	@Column(name="DESCRIPTION", length=100)
	private String description;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="STARTDT")
	private Date startDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="PLANNEDDT")
	private Date plannedDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="RELEASEDT")
	private Date releaseDate;

	
	//bi-directional many-to-one association to ReleaseType
	@ManyToOne
	@JoinColumn(name="TYPEID", referencedColumnName = "ID")
	private ReleaseType releaseType;

	//bi-directional many-to-one association to ReleaseTo
	@ManyToOne
	@JoinColumn(name="TOID", referencedColumnName = "ID")
	private ReleaseTo releaseTo;
		
	//bi-directional many-to-one association to ReleaseStatus
	@ManyToOne
	@JoinColumn(name="STATUSID", referencedColumnName = "ID")
	private ReleaseStatus releaseStatus;
	
	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="MANAGERID", referencedColumnName = "ID")
	private User manager;
	
	
	@Column(name="VERSION")
	private Integer version;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATEDDT")
	private Date createdDate;
	
	@Column(name="CREATEDBY", length=36)
	private String createdBy;

	
	public Release() {
	}

	public Release(String id, String title, String description, Date startDate, Date plannedDate, Date releaseDate,
			ReleaseType releaseType, ReleaseTo releaseTo, ReleaseStatus releaseStatus, User manager, Integer version) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.plannedDate = plannedDate;
		this.releaseDate = releaseDate;
		this.releaseType = releaseType;
		this.releaseTo = releaseTo;
		this.releaseStatus = releaseStatus;
		this.manager = manager;
		this.version = version;
	}

	public Release(String id, String title, String description, Date startDate, Date plannedDate, Date releaseDate,
			ReleaseType releaseType, ReleaseTo releaseTo, ReleaseStatus releaseStatus, User manager, Integer version,
			Date createdDate, String createdBy) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.plannedDate = plannedDate;
		this.releaseDate = releaseDate;
		this.releaseType = releaseType;
		this.releaseTo = releaseTo;
		this.releaseStatus = releaseStatus;
		this.manager = manager;
		this.version = version;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getPlannedDate() {
		return this.plannedDate;
	}

	public void setPlannedDate(Date plannedDate) {
		this.plannedDate = plannedDate;
	}

	public Date getReleaseDate() {
		return this.releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public User getUser() {
		return this.manager;
	}

	public void setUser(User manager) {
		this.manager = manager;
	}

	public ReleaseStatus getReleaseStatus() {
		return this.releaseStatus;
	}

	public void setReleaseStatus(ReleaseStatus releaseStatus) {
		this.releaseStatus = releaseStatus;
	}

	public ReleaseTo getReleaseTo() {
		return this.releaseTo;
	}

	public void setReleaseTo(ReleaseTo releaseTo) {
		this.releaseTo = releaseTo;
	}

	public ReleaseType getReleaseType() {
		return this.releaseType;
	}

	public void setReleaseType(ReleaseType releaseType) {
		this.releaseType = releaseType;
	}

	
	@Override
	public String toString() {
		return "Release [id=" + id + ", title=" + title + ", description=" + description + ", startDate=" + startDate
				+ ", plannedDate=" + plannedDate + ", releaseDate=" + releaseDate + ", releaseType=" + releaseType
				+ ", releaseTo=" + releaseTo + ", releaseStatus=" + releaseStatus + ", manager=" + manager
				+ ", version=" + version + ", createdDate=" + createdDate + ", createdBy=" + createdBy
				+ "]";
	}

}