package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;

import com.cybage.utility.Utility;

import java.util.Date;
import java.util.List;


@Entity
@Table(name="release")
public class Release implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;
	
	@Column(name="TITLE", length=45, nullable=false, unique=true)
	private String title;
	
	@Column(name="DESCRIPTION", length=100)
	private String description;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="STARTDT")
	private Date startDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="PLANNEDDT")
	private Date plannedDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="RELEASEDT")
	private Date releaseDate;

	
	//bi-directional many-to-one association to ReleaseType
	@ManyToOne
	@JoinColumn(name="TYPEID", referencedColumnName = "ID")
	private ReleaseType releaseType;

	//bi-directional many-to-one association to ReleaseTo
	@ManyToOne
	@JoinColumn(name="TOID", referencedColumnName = "ID")
	private ReleaseTo releaseTo;
		
	//bi-directional many-to-one association to ReleaseStatus
	@ManyToOne
	@JoinColumn(name="STATUSID", referencedColumnName = "ID")
	private ReleaseStatus releaseStatus;
	
	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="MANAGERID", referencedColumnName = "ID")
	private User manager;
	
	
	@Column(name="VERSION")
	private Integer version;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATEDDT")
	private Date createdDate;
	
	@Column(name="CREATEDBY", length=36, nullable=false)
	private String createdBy;


	//bi-directional many-to-one association to ReleaseItem
	@OneToMany(mappedBy="release", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<ReleaseItem> releaseItems;

	//bi-directional many-to-one association to ReleaseIteration
	@OneToMany(mappedBy="release", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<ReleaseIteration> releaseIterations;

	//bi-directional many-to-one association to ReleaseLog
	@OneToMany(mappedBy="release", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<ReleaseLog> releaseLogs;
	
	//default constructor
	public Release() {
		this.id = Utility.getUUID();
	}
	
	//parameterized constructor
	public Release(String title, String description, Date startDate, Date plannedDate, Date releaseDate,
			ReleaseType releaseType, ReleaseTo releaseTo, ReleaseStatus releaseStatus, User manager, Integer version,
			Date createdDate, String createdBy, List<ReleaseItem> releaseItems,
			List<ReleaseIteration> releaseIterations, List<ReleaseLog> releaseLogs) {
		this.id = Utility.getUUID();
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.plannedDate = plannedDate;
		this.releaseDate = releaseDate;
		this.releaseType = releaseType;
		this.releaseTo = releaseTo;
		this.releaseStatus = releaseStatus;
		this.manager = manager;
		this.version = version;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.releaseItems = releaseItems;
		this.releaseIterations = releaseIterations;
		this.releaseLogs = releaseLogs;
	}

	//Getter Setter
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getPlannedDate() {
		return plannedDate;
	}

	public void setPlannedDate(Date plannedDate) {
		this.plannedDate = plannedDate;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public ReleaseType getReleaseType() {
		return releaseType;
	}

	public void setReleaseType(ReleaseType releaseType) {
		this.releaseType = releaseType;
	}

	public ReleaseTo getReleaseTo() {
		return releaseTo;
	}

	public void setReleaseTo(ReleaseTo releaseTo) {
		this.releaseTo = releaseTo;
	}

	public ReleaseStatus getReleaseStatus() {
		return releaseStatus;
	}

	public void setReleaseStatus(ReleaseStatus releaseStatus) {
		this.releaseStatus = releaseStatus;
	}

	public User getManager() {
		return manager;
	}

	public void setManager(User manager) {
		this.manager = manager;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public List<ReleaseItem> getReleaseItems() {
		return releaseItems;
	}

	public void setReleaseItems(List<ReleaseItem> releaseItems) {
		this.releaseItems = releaseItems;
	}

	public List<ReleaseIteration> getReleaseIterations() {
		return releaseIterations;
	}

	public void setReleaseIterations(List<ReleaseIteration> releaseIterations) {
		this.releaseIterations = releaseIterations;
	}

	public List<ReleaseLog> getReleaseLogs() {
		return releaseLogs;
	}

	public void setReleaseLogs(List<ReleaseLog> releaseLogs) {
		this.releaseLogs = releaseLogs;
	}

	
}