package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name="release")
public class Release implements Serializable {
	private static final long serialVersionUID = 1L;

	private String id;
	
	private String title;
	
	private String description;
	
	private Date startDate;
	
	private Date plannedDate;
	
	private Date releaseDate;
	
	//bi-directional many-to-one association to ReleaseType
	private ReleaseType releaseType;

	//bi-directional many-to-one association to ReleaseTo
	private ReleaseTo releaseTo;
		
	//bi-directional many-to-one association to ReleaseStatus
	private ReleaseStatus releaseStatus;
	
	//bi-directional many-to-one association to User
	private User manager;
	
	private Integer version;

	private Date createdDate;
	
	private String createdBy;

	
	public Release() {
	}

	public Release(String id, String title, String description, Date startDate, Date plannedDate, Date releaseDate,
			ReleaseType releaseType, ReleaseTo releaseTo, ReleaseStatus releaseStatus, User manager, Integer version) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.plannedDate = plannedDate;
		this.releaseDate = releaseDate;
		this.releaseType = releaseType;
		this.releaseTo = releaseTo;
		this.releaseStatus = releaseStatus;
		this.manager = manager;
		this.version = version;
	}

	public Release(String id, String title, String description, Date startDate, Date plannedDate, Date releaseDate,
			ReleaseType releaseType, ReleaseTo releaseTo, ReleaseStatus releaseStatus, User manager, Integer version,
			Date createdDate, String createdBy) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.plannedDate = plannedDate;
		this.releaseDate = releaseDate;
		this.releaseType = releaseType;
		this.releaseTo = releaseTo;
		this.releaseStatus = releaseStatus;
		this.manager = manager;
		this.version = version;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
	}
	
	@Id
	@Column(name="ID", length=36)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Column(name="CREATEDBY", length=36)
	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATEDDT")
	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Column(name="DESCRIPTION", length=100)
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="PLANNEDDT")
	public Date getPlannedDate() {
		return this.plannedDate;
	}

	public void setPlannedDate(Date plannedDate) {
		this.plannedDate = plannedDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="RELEASEDT")
	public Date getReleaseDate() {
		return this.releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="STARTDT")
	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	@Column(name="TITLE", length=45)
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	@Column(name="VERSION")
	public int getVersion() {
		return this.version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="MANAGERID")
	public User getUser() {
		return this.manager;
	}

	public void setUser(User manager) {
		this.manager = manager;
	}
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="STATUSID")
	public ReleaseStatus getReleaseStatus() {
		return this.releaseStatus;
	}

	public void setReleaseStatus(ReleaseStatus releaseStatus) {
		this.releaseStatus = releaseStatus;
	}
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="TOID")
	public ReleaseTo getReleaseTo() {
		return this.releaseTo;
	}

	public void setReleaseTo(ReleaseTo releaseTo) {
		this.releaseTo = releaseTo;
	}

	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="TYPEID")
	public ReleaseType getReleaseType() {
		return this.releaseType;
	}

	public void setReleaseType(ReleaseType releaseType) {
		this.releaseType = releaseType;
	}

	
	@Override
	public String toString() {
		return "Release [id=" + id + ", title=" + title + ", description=" + description + ", startDate=" + startDate
				+ ", plannedDate=" + plannedDate + ", releaseDate=" + releaseDate + ", releaseType=" + releaseType
				+ ", releaseTo=" + releaseTo + ", releaseStatus=" + releaseStatus + ", manager=" + manager
				+ ", version=" + version + ", createdDate=" + createdDate + ", createdBy=" + createdBy
				+ "]";
	}

}