package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;

import com.cybage.utility.Utility;

import java.util.Date;
import java.util.List;


@Entity
@Table(name="items")
public class Item implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;
	
	@Column(name="DESCRIPTION", length=100)
	private String description;

	@Column(name="NAME", length=45, nullable=false)
	private String name;

	@Column(name="CREATEDBY", length=36, nullable=false)
	private String createdBy;

	@Column(name="CREATEDDT", nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	

	//bi-directional many-to-one association to ItemsLog
	@OneToMany(mappedBy="item", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<ItemsLog> itemsLogs;

	//bi-directional many-to-one association to IterationItem
	@OneToMany(mappedBy="item", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<IterationItem> iterationItems;

	//bi-directional many-to-one association to ReleaseItem
	@OneToMany(mappedBy="item", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<ReleaseItem> releaseItems;

	public Item() {
		this.id = Utility.getUUID();
	}
	
	//parameterized constructor
	public Item(String description, String name, String createdBy, Date createdDate, List<ItemsLog> itemsLogs,
			List<IterationItem> iterationItems, List<ReleaseItem> releaseItems) {
		this.id = Utility.getUUID();
		this.description = description;
		this.name = name;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.itemsLogs = itemsLogs;
		this.iterationItems = iterationItems;
		this.releaseItems = releaseItems;
	}



	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ItemsLog> getItemsLogs() {
		return itemsLogs;
	}

	public void setItemsLogs(List<ItemsLog> itemsLogs) {
		this.itemsLogs = itemsLogs;
	}

	public List<IterationItem> getIterationItems() {
		return iterationItems;
	}

	public void setIterationItems(List<IterationItem> iterationItems) {
		this.iterationItems = iterationItems;
	}

	public List<ReleaseItem> getReleaseItems() {
		return releaseItems;
	}

	public void setReleaseItems(List<ReleaseItem> releaseItems) {
		this.releaseItems = releaseItems;
	}
	

}