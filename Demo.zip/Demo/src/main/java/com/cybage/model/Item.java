package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name="items")
public class Item implements Serializable {
	private static final long serialVersionUID = 1L;


	@Id
	private String id;
	
	@Column(name="DESCRIPTION", length=100)
	private String description;

	@Column(name="NAME", length=45)
	private String name;

	@Column(name="CREATEDBY", length=36)
	private String createdBy;

	@Column(name="CREATEDDT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	public Item() {
	}
	
	public Item(String id, String description, String name) {
		super();
		this.id = id;
		this.description = description;
		this.name = name;
	}

	public Item(String id, String description, String name, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.description = description;
		this.name = name;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}


	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	@Override
	public String toString() {
		return "Item [id=" + id + ", description=" + description + ", name=" + name + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + "]";
	}
	
	

}