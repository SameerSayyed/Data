package com.cybage.model;

import java.io.Serializable;

import javax.persistence.*;

import com.cybage.utility.Utility;



@Entity
@Table(name="userrole")
public class UserRole implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private String id;
	
	@ManyToOne
	@JoinColumn(name="ROLEID", referencedColumnName = "ID")
	private Role role;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="USERID", referencedColumnName = "ID")
	private User user;
	
	//Default Constructor
	public UserRole() {
		this.id = Utility.getUUID();
	}
	
	//parameterized constructor
	public UserRole(Role role, User user) {
		this.id = Utility.getUUID();
		this.role = role;
		this.user = user;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	
}
