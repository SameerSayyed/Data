package com.cybage.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cybage.model.User;
import com.cybage.service.HomeService;

@Controller
@RequestMapping("/home")
public class HomeController {
	
	@Autowired
	HomeService service;
	
	public HomeController() {
		System.out.println("Home Controller Ctor");
	}
	
	
	/*Home Page Redirection*/
	@RequestMapping(value="/home")
	public String showNextPage()
	{
		System.out.println("In showNextPage");
		return "Home";
	}
	
	@RequestMapping(value = "/aboutus")
	public String showAboutUsPage(){
		System.out.println("In showAboutUsPage");
		return "AboutUs";
	}
	
	@RequestMapping(value = "/login")
	public String showLoginForm(@ModelAttribute("user") User user){
		System.out.println("In showLoginForm");
		return "Login";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String processLoginForm(@ModelAttribute("user") User user, ModelMap model, HttpSession session){
		
		/*String status = service.userLogin(user);
		System.out.println("login status : " + status);
		if(status != null)
			return status;*/
		model.addAttribute("status", "Invalid Username or Password");
		
		return "Login";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String showRegisterForm(@ModelAttribute("user") User user)
	{
		System.out.println("IN showRegisterForm");
		return "Register";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String processRegisterForm(@ModelAttribute User user, ModelMap model)
	{
		
		//user= service.registerUser(user);
		
		model.addAttribute("status", "Registered Successfully");
		return "Home";
	}
	
}
