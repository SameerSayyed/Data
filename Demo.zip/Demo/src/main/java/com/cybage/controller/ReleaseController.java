package com.cybage.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cybage.model.Release;
import com.cybage.model.ReleaseLog;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.service.ReleaseService;
import com.cybage.utility.Utility;

@Controller
@RequestMapping("/release")
public class ReleaseController {
	
	@Autowired
	private ReleaseService service;
	
	public ReleaseController() {
		System.out.println("Release Controller");
	}
	
	@RequestMapping(value="home")
	public String showReleasePage(){
		return "Release";
	}
	
	@RequestMapping(value="/allReleases")
	public String getAllReleases(){
		
		List<Release> releases =  service.getAllReleases();
		//service.getAllReleasesWithIterations();
		
		if(releases != null)
			System.out.println("Not Null");
		else
			System.out.println("Null");
		
		return "redirect:/home/home";
	}
	
	@RequestMapping(value="/addRelease")
	public String addRelease(){
		
		ReleaseType releaseType = new ReleaseType("c7603150-04fd-47b1-99ba-ed50d80bdfcf", "Build");
		ReleaseTo releaseTo = new ReleaseTo("df412194-47ed-4b5f-958b-c76f8136c5ca", "Dev Test");
		ReleaseStatus releaseStatus = new ReleaseStatus("ad92f715-0b6a-491b-9b6d-a07860f7802f", "Delayed");
		User manager = new User("63d6398e-fb00-4a7a-86a0-6c44b451a208", "Project", "Manager", "pm@cybage.com", "u34HOhoXLyOgmMZWkxeCkA==");
		
		Release release = new Release(Utility.getUUID(), "Title", "Desc", new Date(), new Date(), new Date(),
				releaseType, releaseTo, releaseStatus, manager, 1);
		ReleaseLog releaseLog = new ReleaseLog(Utility.getUUID(), "63d6398e-fb00-4a7a-86a0-6c44b451a208", new Date(), release);
		
		System.out.println(service.addRelease(release, releaseLog));
		
		return "redirect:/home/home";
	}
}
